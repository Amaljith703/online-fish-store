package com.example.anew;

public class BidAddContent {
   private String name;
   private  String discription;
   private String minbid;
   private String img;
   private String bidrate;
   private String status;
  private String time;
  private String buyer;
  private String productid;
  private String fisherid;
private  String buyid;

    public String getBuyid() {
        return buyid;
    }

    public void setBuyid(String buyid) {
        this.buyid = buyid;
    }

    public String getFisherid() {
        return fisherid;
    }

    public void setFisherid(String fisherid) {
        this.fisherid = fisherid;
    }

    public String getProductid() {
        return productid;
    }

    public void setProductid(String productid) {
        this.productid = productid;
    }

    public String getBuyer() {
        return buyer;
    }

    public void setBuyer(String buyer) {
        this.buyer = buyer;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDiscription() {
        return discription;
    }

    public void setDiscription(String discription) {
        this.discription = discription;
    }

    public String getMinbid() {
        return minbid;
    }

    public void setMinbid(String minbid) {
        this.minbid = minbid;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getBidrate() {
        return bidrate;
    }

    public void setBidrate(String bidrate) {
        this.bidrate = bidrate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
