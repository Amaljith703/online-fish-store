package com.example.anew.ui.dashboard;

import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.TranslateAnimation;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Pie;
import com.example.anew.FishPriceAdapter;
import com.example.anew.R;
import com.example.anew.StockAdapter;
import com.example.anew.StockItem;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.example.anew.FisherMainHome.fab;
import static com.example.anew.FisherMainHome.navView;

public class DashboardFragment extends Fragment {
    CardView cardView;
    FloatingActionButton fb;
    AutoCompleteTextView name;
    EditText qty;
    AnyChartView anyChartView;
    FirebaseDatabase rdb;
    ArrayList<StockItem> stk;
    List<DataEntry> dataEntries;
    ArrayList fishes = new ArrayList();
    RecyclerView rs;
    StockAdapter mAdapter;
    Button cancel, add;
    boolean opened;
    int chk = 0;
    Pie pie;
    int k = 0,r=0;
    String ider = null;
    float cqty = 0;
    ArrayAdapter<String> adapter;
    private DashboardViewModel dashboardViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        dashboardViewModel =
                ViewModelProviders.of(this).get(DashboardViewModel.class);
        View root = inflater.inflate(R.layout.fragment_dashboard, container, false);
        fab.setVisibility(View.INVISIBLE);
        navView.getMenu().findItem(R.id.navigation_dashboard).setChecked(true);
        cardView = root.findViewById(R.id.cardstock);
        fb = root.findViewById(R.id.stockfloatbt);
        rdb = FirebaseDatabase.getInstance();
        anyChartView=root.findViewById(R.id.piechart);
        name = root.findViewById(R.id.autocompletetext);
        qty = root.findViewById(R.id.stockqty);
        add = root.findViewById(R.id.stockadd);
        cancel = root.findViewById(R.id.stockcancel);
        cardView.setVisibility(View.INVISIBLE);
        rs=root.findViewById(R.id.stockrecycler);
        rs.setLayoutManager(new LinearLayoutManager(getContext()));
        stk = new ArrayList<>();
        mAdapter=new StockAdapter(stk);
        rs.setAdapter(mAdapter);
        dataEntries=new ArrayList<>();
        pie= AnyChart.pie();
        anyChartView.setChart(pie);
        getDatasForAoto();
        name.setVisibility(View.INVISIBLE);
        qty.setVisibility(View.INVISIBLE);
        add.setVisibility(View.INVISIBLE);
        cancel.setVisibility(View.INVISIBLE);
        adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, fishes);
        name.setAdapter(adapter);
        opened = false;
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                close();
            }
        });
        fb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!opened) {
                    name.setVisibility(View.VISIBLE);
                    cardView.setVisibility(View.VISIBLE);
                    qty.setVisibility(View.VISIBLE);
                    add.setVisibility(View.VISIBLE);
                    cancel.setVisibility(View.VISIBLE);
                    TranslateAnimation animate = new TranslateAnimation(
                            0,
                            0,
                            cardView.getHeight(),
                            0);
                    animate.setDuration(500);
                    animate.setFillAfter(true);
                    cardView.startAnimation(animate);
                    Handler b = new Handler();
                    b.postDelayed(new Runnable() {
                        @Override
                        public void run() {


                        }
                    }, 200);
                    opened = !opened;
                    fb.setVisibility(View.INVISIBLE);

                }
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check();
            }
        });
        return root;
    }

    public void close() {
        if (opened) {
            cardView.setVisibility(View.VISIBLE);

            name.setVisibility(View.INVISIBLE);
            qty.setVisibility(View.INVISIBLE);
            add.setVisibility(View.INVISIBLE);
            cancel.setVisibility(View.INVISIBLE);

            TranslateAnimation animate = new TranslateAnimation(
                    0,
                    0,
                    0,
                    cardView.getHeight());
            animate.setDuration(300);
            animate.setFillAfter(true);
            cardView.startAnimation(animate);
            Handler b = new Handler();
            b.postDelayed(new Runnable() {
                @Override
                public void run() {
                    cardView.setVisibility(View.INVISIBLE);
                    fb.setVisibility(View.VISIBLE);
                }
            }, 300);
            opened = !opened;
        }
    }

    public void getDatasForAoto() {
        Calendar cl = Calendar.getInstance();
        String date = "" + (cl.get(Calendar.DAY_OF_MONTH));
        date = date + "-" + cl.get(Calendar.MONTH) + "-" + cl.get(Calendar.YEAR);
        Log.d("logs", date);
        rdb.getReference().child("STOCK").child(date).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                fishes.clear();
                stk.clear();
                dataEntries.clear();
                for (DataSnapshot d : dataSnapshot.getChildren()) {
                    if (d.exists()) {
                        StockItem ds = d.getValue(StockItem.class);
                        String name = null;
                        name = ds.getName();
                        String id = null;
                        id = ds.getIds();
                        String date = null;
                        date = ds.getDate();
                        float qty = 0;
                        qty = ds.getQty();
                        String loca = null;
                        loca = ds.getLocation();
                        stk.add(new StockItem(date, id, name, loca, qty));
                        fishes.add(name);
                        dataEntries.add(new ValueDataEntry(name,qty));
                    }
                }
                mAdapter.insertAll(stk);
                mAdapter.notifyDataSetChanged();
                adapter.notifyDataSetChanged();
                pie.data(dataEntries);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    @Override
    public void onResume() {
        navView.getMenu().findItem(R.id.navigation_dashboard).setChecked(true);
        super.onResume();
        getDatasForAoto();
    }

    public void check() {
        int n = 0;
        k = 0;
        chk = 0;//new fish stock in list
        Calendar cl = Calendar.getInstance();
        String date = "" + (cl.get(Calendar.DAY_OF_MONTH));
        date = date + "-" + cl.get(Calendar.MONTH) + "-" + cl.get(Calendar.YEAR);
        cqty = 0;
        final String namer = name.getText().toString().trim();
        final float qtyr = Float.parseFloat(qty.getText().toString().trim());
        {
            if (namer.length() == 0) {
                n = 1;
                name.setError("fill column");
            } else {
                n = 0;
                name.setError(null);
            }
            if (qtyr == 0.00) {
                n = 1;
                qty.setError("fill column");
            } else {
                qty.setError(null);
                n = 0;
            }
            if (n == 1) {

            } else {
                final String finalDate = date;
                rdb.getReference().child("STOCK").child(date).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (k == 0) {
                            for (DataSnapshot ds : dataSnapshot.getChildren()) {
                                if (ds.exists()) {
                                    String temp = ds.child("name").getValue(String.class);
                                    if (namer.toLowerCase().equals(temp)) {
                                        chk = 1;
                                        ider = ds.getKey();
                                        cqty = ds.child("qty").getValue(float.class);
                                    }
                                }
                            }
                            if (chk == 1) {
                                cqty = qtyr + cqty;
                                Map<String, Object> map = new HashMap<>();
                                map.put("name", namer);
                                map.put("qty", cqty);
                                map.put("location", "Idukki");
                                rdb.getReference().child("STOCK").child(finalDate).child(ider).updateChildren(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Toast.makeText(getContext(), "Saved Sucessfully", Toast.LENGTH_SHORT).show();
                                            name.setText("");
                                            qty.setText("");
                                            k = 1;
                                        }
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {

                                    }
                                });
                            } else {
                                StockItem ms = new StockItem();
                                ms.setName(namer);
                                ms.setQty(qtyr);
                                ms.setLocation("Idukki");
                                rdb.getReference().child("STOCK").child(finalDate).push().setValue(ms).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Toast.makeText(getContext(), "Saved Sucessfully", Toast.LENGTH_SHORT).show();
                                            name.setText("");
                                            qty.setText("");
                                            k = 1;
                                        }
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {

                                    }
                                });
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
        }
    }

}