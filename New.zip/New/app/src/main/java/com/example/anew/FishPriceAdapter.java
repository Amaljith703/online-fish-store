package com.example.anew;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class FishPriceAdapter extends RecyclerView.Adapter <FishPriceAdapter.FishPriceViewHolder>{
   private ArrayList<UserBidDatas> mBloodDonateList;
   private OnItemClickListener mListener;
  Context context;
   public interface  OnItemClickListener{
       void onItemClick(int position);
   }
   public void setOnItemClickListener(OnItemClickListener listener)
   {
       mListener=listener;
   }
    public  static class FishPriceViewHolder extends RecyclerView.ViewHolder
    {
        public TextView mTextView1;
        public TextView mTextView2;
        public ImageView imageView;

        public FishPriceViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);
            mTextView1=itemView.findViewById(R.id.fTextView1);
            mTextView2=itemView.findViewById(R.id.fTextView2);
            imageView=itemView.findViewById(R.id.fishimgview);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
if(listener!=null)
{
int position=getAdapterPosition();
if (position!=RecyclerView.NO_POSITION)
{
    listener.onItemClick(position);
}
}
                }
            });
        }
    }
    public FishPriceAdapter(ArrayList<UserBidDatas> bloodlist)
    {
        mBloodDonateList=bloodlist;
        Log.d("lll",""+mBloodDonateList.size());
    }

    @NonNull
    @Override
    public FishPriceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
     View v=LayoutInflater.from(parent.getContext()).inflate(R.layout.fish_content, parent, false);
     FishPriceViewHolder bdvh=new FishPriceViewHolder(v,mListener);
        return bdvh;
    }

    @Override
    public void onBindViewHolder(@NonNull FishPriceViewHolder holder, int position) {
        UserBidDatas currentitem=mBloodDonateList.get(position);
   //   Picasso.with(context).load(currentitem.getImg()).into(holder.imageView);
Glide.with(context).load(currentitem.getImg())
                .apply(new RequestOptions().transform(new RoundedCorners(10)))
                .into(holder.imageView);
        holder.mTextView1.setText(currentitem.getName());
        holder.mTextView2.setText(currentitem.getPrice());

    }

    @Override
    public int getItemCount() {
        return mBloodDonateList.size();
    }

}
