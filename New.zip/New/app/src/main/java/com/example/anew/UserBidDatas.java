package com.example.anew;

import android.net.Uri;

public class UserBidDatas {
    private String name;
    private  String discription;
    private String minbid;
    private Uri img;
    private String bidrate;
    private String status;
    private String time;
    private String buyer;
    private String productid;
    private String fisherid;
    private String price;

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
 public UserBidDatas()
 {

 }
    public UserBidDatas(String name, String discription, String minbid, Uri img, String bidrate, String status, String time, String buyer, String productid, String fisherid)
    {
       setName(name);
       setDiscription(discription);
       setMinbid(minbid);
       setImg(img);
       setBidrate(bidrate);
       setStatus(status);
       setTime(time);
       setBuyer(buyer);
       setProductid(productid);
       setFisherid(fisherid);
    }
    public UserBidDatas insertdata(String ider, String namer, String pricer, Uri im)
    {
        UserBidDatas s=new UserBidDatas();
        s.setFisherid(ider);
        s.setName(namer);
        s.setPrice(pricer);
        s.setImg(im);
        return s;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDiscription() {
        return discription;
    }

    public void setDiscription(String discription) {
        this.discription = discription;
    }

    public String getMinbid() {
        return minbid;
    }

    public void setMinbid(String minbid) {
        this.minbid = minbid;
    }

    public Uri getImg() {
        return img;
    }

    public void setImg(Uri img) {
        this.img = img;
    }

    public String getBidrate() {
        return bidrate;
    }

    public void setBidrate(String bidrate) {
        this.bidrate = bidrate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getBuyer() {
        return buyer;
    }

    public void setBuyer(String buyer) {
        this.buyer = buyer;
    }

    public String getProductid() {
        return productid;
    }

    public void setProductid(String productid) {
        this.productid = productid;
    }

    public String getFisherid() {
        return fisherid;
    }

    public void setFisherid(String fisherid) {
        this.fisherid = fisherid;
    }

}
