package com.example.anew;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.anew.ui.home.HomeFragment;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;


import static com.example.anew.FisherMainHome.fab;
import static com.example.anew.FisherMainHome.navView;


public class AddBidFragment extends Fragment {
 Button btn,savebtn;
 ImageView img,ext;

 int n=0,mbu=0;
 static int faber=0;
 private    String nm=null,dis=null,mrp=null;
 EditText pdtname,disri,pdtprice;
 private FirebaseDatabase rdb;
    private StorageTask mtask;
    StorageReference storageimg;
    SharedPreferences sharedPreferences;

    private static final int CAMERA_REQUEST=101;
    private Uri mCapturedImageURI,upURI,downloadUrl=null;
    File imgfile,f;
   public static String  productidd;
    Intent serviceIntent;
    ProgressBar ps;
    BidAddContent bid;
  private   View view;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
       view= inflater.inflate(R.layout.fragment_add_bid, container, false);
        img=view.findViewById(R.id.img);
        btn=view.findViewById(R.id.takeimg);
        pdtname=view.findViewById(R.id.pdtname);
        disri=view.findViewById(R.id.pdtdisciption);
        pdtprice=view.findViewById(R.id.pdtprice);
        ps=view.findViewById(R.id.progrsser);
        ps.setVisibility(View.INVISIBLE);
        navView.setVisibility(View.INVISIBLE);
        faber=1;

       Context context;
       sharedPreferences=getContext().getSharedPreferences("LOCAL", Context.MODE_PRIVATE);
        rdb=FirebaseDatabase.getInstance();
        fab.setVisibility(View.INVISIBLE);
        savebtn=view.findViewById(R.id.savebtn);
        storageimg= FirebaseStorage.getInstance().getReference("PRODUCT");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fileName = "temp.jpg";
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.TITLE, fileName);
                URL url;
                mCapturedImageURI = getActivity().getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                imgfile=new File( mCapturedImageURI.getPath());
                f=new File(imgfile, imgfile.getName());
                Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                //if(cameraIntent.resolveActivity(getPackageManager())!=null)
                intent.putExtra(MediaStore.EXTRA_OUTPUT, mCapturedImageURI);
                startActivityForResult(intent,CAMERA_REQUEST);
            }
        });


        savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {cliccc();
            }
        });





        // The callback can be enabled or disabled here or in handleOnBackPressed()

        return view;
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
            //  Bitmap photo = (Bitmap) data.getExtras().get("data");
            //   img.setImageBitmap(photo);
            //  img.setImageURI(mCapturedImageURI);  //// used to insert image into image view using uri of the image
            InputStream imageStream = null;
            try {
                imageStream = getActivity().getContentResolver().openInputStream(mCapturedImageURI);
                Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                selectedImage = getResizedBitmap(selectedImage, 400);
                img.setImageBitmap(selectedImage);
                n=1;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

    }
    private String getExtension(Uri uri)
    {
        ContentResolver cr=getActivity().getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(cr.getType(uri));
    }

public void testerrr()
{


    serviceIntent = new Intent(getContext(), BidIntentService.class);
    serviceIntent.putExtra("bider", "Bid");
    getActivity().startService( serviceIntent);
}
    public void cliccc() {
        ps.setVisibility(View.VISIBLE);
        savebtn.setEnabled(false);
        // CALL THIS METHOD TO GET THE ACTUAL PATH
        //  Toast.makeText(this, ""+mCapturedImageURI.toString()+" "+getExtension(mCapturedImageURI), Toast.LENGTH_LONG).show();
        if (n == 0) {
            Toast.makeText(getContext(), "Please select image", Toast.LENGTH_SHORT).show();
            ps.setVisibility(View.INVISIBLE);
            savebtn.setEnabled(true);
        } else {
            Boolean netcheck = isNetworkAvailable();
            if(netcheck==true) {
              try  {
                int cnt = 0;
                nm = pdtname.getText().toString().trim();
                dis = disri.getText().toString().trim();
                mrp = pdtprice.getText().toString().trim();
                if (nm == null || nm.equals("") || nm.equals(" ")) {
                    cnt = +1;
                    pdtname.setError("Please fill column");
                }
                if (dis == null || dis.equals("") || dis.equals(" ")) {
                    cnt = +1;
                    disri.setError("Please fill coumn");
                }
                if (mrp == null || mrp.equals("") || mrp.equals(" ")) {
                    cnt = +1;
                    pdtprice.setError("Please fill coumn");
                }
                if (cnt != 0) {
                    ps.setVisibility(View.INVISIBLE);
                    savebtn.setEnabled(true);
                    Snackbar.make(view, "Please fill columns correctly", Snackbar.LENGTH_SHORT).show();
                } else {

                    Log.d("vvvvvv", "" + netcheck);
                    if (netcheck == true) {
                        final StorageReference rf = storageimg.child(System.currentTimeMillis() + "." + getExtension(mCapturedImageURI));
                        mtask = rf.putFile(mCapturedImageURI)
                                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                    @Override
                                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                        // Get a URL to the uploaded content
                                        //   Uri downloadUrl = taskSnapshot.getDownloadUrl();
                                        rf.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                            @Override
                                            public void onSuccess(Uri uri) {

                                                downloadUrl = uri;
                                                Log.d("ttt", "download url" + downloadUrl);
                                                if (downloadUrl == null) {
                                                    ps.setVisibility(View.INVISIBLE);
                                                    savebtn.setEnabled(true);
                                                    Toast.makeText(getActivity(), "Something went wrong.\n please try again later", Toast.LENGTH_LONG).show();
                                                } else {
                                                    final String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                                                    final String currentTime = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
                                                    final String usrid = sharedPreferences.getString("ID", null);
                                                    //  DatabaseReference postsRef = rdb.getReference().child(currentDate).child(usrid);
                                                    bid = new BidAddContent();
                                                    bid.setName(nm);
                                                    bid.setDiscription(dis);
                                                    bid.setMinbid(mrp);
                                                    bid.setImg(downloadUrl.toString());
                                                    bid.setBidrate("0");
                                                    bid.setStatus("wait");
                                                    bid.setBuyer("NON");
                                                    bid.setBuyid("NON");
                                                    bid.setTime(currentTime);
                                                    bid.setFisherid(usrid);
                                                    //    map.put("TIME",currentTime);
                                                    productidd = "" + rdb.getReference().child("BID").child(currentDate).child(usrid).push().getKey();
                                                    bid.setProductid(productidd);
                                                    Log.d("ttt", "iddd: " + productidd);
                                                    rdb.getReference().child("BID").child(currentDate).child(usrid).child(productidd).setValue(bid).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                        @Override
                                                        public void onComplete(@NonNull Task<Void> task) {
                                                            if (task.isSuccessful()) {

                                                                UsrBidData usrBidData = new UsrBidData();
                                                                usrBidData.setCudate(currentDate);
                                                                usrBidData.setSfishrID(usrid);
                                                                usrBidData.setSpid(productidd);
                                                                rdb.getReference().child("history").child(usrid).child(productidd).setValue(usrBidData).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                    @Override
                                                                    public void onComplete(@NonNull Task<Void> task) {
                                                                        if (task.isSuccessful()) {
                                                                            Snackbar.make(view, "Bid saved sucessfully", Snackbar.LENGTH_SHORT).show();
                                                                        } else {
                                                                            Toast.makeText(getActivity(), "Unable to add this bid to history", Toast.LENGTH_SHORT).show();
                                                                        }
                                                                    }
                                                                });

                                                                new BidIntentService().idCintainer(productidd);
                                                                serviceIntent = new Intent(getContext(), BidIntentService.class);
                                                                serviceIntent.putExtra("inputExtra", "Bid");
                                                                ContextCompat.startForegroundService(getContext(), serviceIntent);
                                                                ps.setVisibility(View.INVISIBLE);
                                                                savebtn.setEnabled(true);
                                                                getActivity().onBackPressed();
                                                            }
                                                            else
                                                            {
                                                                ps.setVisibility(View.INVISIBLE);
                                                                savebtn.setEnabled(true);
                                                            }
                                                        }
                                                    }).addOnFailureListener(new OnFailureListener() {
                                                        @Override
                                                        public void onFailure(@NonNull Exception e) {
                                                            Log.d("ttt", "error db :" + e);
                                                            ps.setVisibility(View.INVISIBLE);
                                                            savebtn.setEnabled(true);
                                                        }
                                                    });
                                                }
                                            }
                                        }).addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                Log.d("imgerror", "error :" + e);
                                                ps.setVisibility(View.INVISIBLE);
                                                savebtn.setEnabled(true);
                                            }
                                        });
                                    }
                                })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception exception) {
                                        ps.setVisibility(View.INVISIBLE);
                                        savebtn.setEnabled(true);
                                        Toast.makeText(getActivity(), "failed to insert  " + exception, Toast.LENGTH_LONG).show();
                                    }
                                });
                  /*      File localFile = null;
                        try {
                            localFile = File.createTempFile("images", "jpg");
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                   */


                    } else {
                        ps.setVisibility(View.INVISIBLE);
                        savebtn.setEnabled(true);
                        Snackbar.make(view, "no network connection", Snackbar.LENGTH_SHORT).show();

                    }
                }
            }
              catch (NumberFormatException e)
              {
                  ps.setVisibility(View.INVISIBLE);
                  savebtn.setEnabled(true);
              }
        }
    }
    }
///////////////////////////////////////////////RESIZE IMAGE WHICH IS COVERTED INTO BITMAP
    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float)width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }
//////////////////////////////////////////////////////////////
public boolean isNetworkAvailable() {
    ConnectivityManager connectivityManager
            = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
    assert connectivityManager != null;
    NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
    return activeNetworkInfo != null && activeNetworkInfo.isConnected();
}
}
