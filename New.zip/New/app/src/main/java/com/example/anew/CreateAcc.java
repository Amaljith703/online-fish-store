package com.example.anew;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.remote.WatchChange;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static android.widget.Toast.LENGTH_SHORT;



public class CreateAcc extends AppCompatActivity {
    EditText name, address, id, ph, pass, user;
    Spinner loca;
    Button chk;
    Drawable errorIcon;
    int numF = 0, numff = 0, numft = 0,vb=0;
    ArrayList<String> arrayList;
    ArrayAdapter<String> arrayAdapter;
    FirebaseFirestore mFire;
    ProgressBar progs;
    private String typeac = null, doc = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_acc);
        name = findViewById(R.id.namer);
        progs=findViewById(R.id.progrebarmain);
        errorIcon = getResources().getDrawable(R.drawable.ic_check_circle_green);
        errorIcon.setBounds(new Rect(0, 0, errorIcon.getIntrinsicWidth(), errorIcon.getIntrinsicHeight()));
        user = findViewById(R.id.usernmer);
        mFire = FirebaseFirestore.getInstance();
        address = findViewById(R.id.addresser);
        loca = findViewById(R.id.locationer);
        id = findViewById(R.id.fisherid);

        ph = findViewById(R.id.contacter);
        pass = findViewById(R.id.passworder);
        chk = findViewById(R.id.createaccount);
        pass.setVisibility(View.INVISIBLE);
        chk.setEnabled(false);
        user.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int length = s.length();
                String name = s.toString();
                if(isNetworkAvailable()==false)
                {
                    Toast.makeText(getApplicationContext(), "please enable network", Toast.LENGTH_SHORT).show();
                }
                else if (length < 3) {
                    user.setError("minimum 3 charctors");
                    numft = 1;
                } else {
                    numft = 0;
                    mFire.collection("register").whereEqualTo("USERNAME", name).addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                            for (DocumentChange d : queryDocumentSnapshots.getDocumentChanges()) {
                                if (d.getType() == DocumentChange.Type.ADDED) {
                                    if (d.getDocument().exists()) {
                                        user.setError("username not available");
                                        numft = 1;
                                    } else {
                                        Toast.makeText(CreateAcc.this, "yess", Toast.LENGTH_SHORT).show();

                                    }
                                }
                            }
                        }
                    });
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        id.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                id.setCompoundDrawables(null, null, null, null);
                int length = s.length();
                String name = s.toString();
                if(isNetworkAvailable()==false)
                {
                    Toast.makeText(getApplicationContext(), "please enable network", Toast.LENGTH_SHORT).show();
                }
               else if (length < 6) {
                    id.setError("6 digit register number");
                    numff = 1;
                } else {
                    numff = 0;
                     vb=0;
                    //  id.setError("invalid register number");

                    mFire.collection("register").whereEqualTo("ID", name).addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                            for (DocumentChange d : queryDocumentSnapshots.getDocumentChanges()) {
                                if (d.getType() == DocumentChange.Type.ADDED) {
                                    if (d.getDocument().exists()) {
                                        String nm = null;
                                        doc = d.getDocument().getReference().getId();
                                        Log.d("ttt", "doc id:" + doc);
                                        //     nm = d.getDocument().get("NAME").toString();
                                        if (d.getDocument().get("NAME") != null) {
                                            id.setError("register number not available");
                                            numff = 1;
                                            vb=1;
                                        } else {
                                            vb=1;
                                            id.setError(null);
                                            id.setCompoundDrawables(errorIcon, null, null, null);
                                        }

                                    } else {
                                        id.setError("invalid register number");
                                        Toast.makeText(CreateAcc.this, "yess", Toast.LENGTH_SHORT).show();
                                        numff = 1;
                                    }


                                }
                                else {
                                    id.setError("invalid register number");
                                    Toast.makeText(CreateAcc.this, "yess", Toast.LENGTH_SHORT).show();
                                    numff = 1;
                                }
                            }
                            if(vb==0)
                            {
                                id.setError("invalid register number");
                              //  Toast.makeText(CreateAcc.this, "yess", Toast.LENGTH_SHORT).show();
                                numff = 1;
                            }
                        }
                    });
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        arrayList = new ArrayList<>();
        arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arrayList);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        loca.setAdapter(arrayAdapter);
        ph.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int length = s.length();
                String name = s.toString();
                if(isNetworkAvailable()==false)
                {
                    Toast.makeText(getApplicationContext(), "please enable network", Toast.LENGTH_SHORT).show();
                }
               else if (length < 10) {
                    ph.setError("10 digit contact number");
                    numF = 1;
                } else {
                    numF = 0;
                    mFire.collection("register").whereEqualTo("CONTACT", name).addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                            for (DocumentChange d : queryDocumentSnapshots.getDocumentChanges()) {
                                if (d.getType() == DocumentChange.Type.ADDED) {
                                    if (d.getDocument().exists()) {
                                        ph.setError("number not available");
                                      //  Toast.makeText(CreateAcc.this, "no", Toast.LENGTH_SHORT).show();
                                        numF = 1;
                                    } else {
                                      //  Toast.makeText(CreateAcc.this, "yess", Toast.LENGTH_SHORT).show();

                                    }
                                }
                            }
                        }
                    });
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        chk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateEveryThing(v);
            }
        });
    }

    private void validateEveryThing(View v) {
        final View c = v;
        chk.setEnabled(false);
        progs.setVisibility(View.VISIBLE);
        if(isNetworkAvailable()==false)
        {
            Toast.makeText(this, "please enable network", Toast.LENGTH_SHORT).show();
            chk.setEnabled(true);
            progs.setVisibility(View.INVISIBLE);
        }
        else if (typeac == "fisher") {
            String justid = null, justph = null, justuser = null, justname = null, justaddress = null, justpass = null, justloc = null;
            justname = name.getText().toString().trim();
            justaddress = address.getText().toString().trim();
            justpass = pass.getText().toString().trim();
            justloc = loca.getSelectedItem().toString().trim();
            justid = id.getText().toString().trim();
            justph = ph.getText().toString().trim();
            justuser = user.getText().toString().trim();
            int n = 0;
            if (numff == 1) {
                n = 1;
                Log.d("ttt", "id error");
            }
            if (numF == 1) {
                n = 1;
                ph.setError("number not available");
                Log.d("ttt", "number error");
            }
            if (numft == 1) {
                n = 1;
            }
            if (justname == "" || justname.isEmpty() || justname.equals(" ")) {
                n = 1;
                Log.d("ttt", "name error");
                name.setError("Fill column correctly");
            }
            if (justaddress == "" || justaddress.isEmpty() || justaddress.equals(" ")) {
                n = 1;
                address.setError("Fill column correctly");
                Log.d("ttt", "address error");
            }
            if (justpass == "" || justpass.isEmpty() || justpass.equals(" ")) {
                n = 1;
                pass.setError("Fill column correctly");
                Log.d("ttt", "pass error");
            }
            if (justloc == "Your Location" || justloc == null) {
                n = 1;
                Snackbar.make(c, "Please select location", BaseTransientBottomBar.LENGTH_SHORT).show();
            }
            SystemClock.sleep(3000);
            if (n == 1) {
                Snackbar.make(c, "Please fill columns correctly", BaseTransientBottomBar.LENGTH_SHORT).show();
                chk.setEnabled(true);
                progs.setVisibility(View.INVISIBLE);
                Log.d("ttt", "somewhere error");
            } else {
                Map<String, Object> mp = new HashMap<>();
                mp.put("ID", justid);
                mp.put("NAME", justname);
                mp.put("ADDRESS", justaddress);
                mp.put("LOCATION", justloc);
                mp.put("CONTACT", justph);
                mp.put("USERNAME", justuser);
                mp.put("PASSWORD", justpass);
                mp.put("ACCTYPE", "FISHER");

                mFire.collection("register").document(doc).set(mp).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Successully saved as Fisher", Toast.LENGTH_SHORT).show();
                            chk.setEnabled(true);
                            progs.setVisibility(View.INVISIBLE);
                            startActivity(new Intent(getApplicationContext(), login.class));
                        } else {

                            Snackbar.make(c, "Unable to save profile", BaseTransientBottomBar.LENGTH_SHORT).show();
                            chk.setEnabled(true);
                            progs.setVisibility(View.INVISIBLE);
                        }

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Snackbar.make(c, "Something went wrong", BaseTransientBottomBar.LENGTH_SHORT).show();
                        Log.d("ttt", "error:" + e);
                        chk.setEnabled(true);
                        progs.setVisibility(View.INVISIBLE);
                    }
                });

            }
        } else if (typeac == "distri") {
            String justph = null, justuser = null, justname = null, justaddress = null, justpass = null, justloc = null;
            justname = name.getText().toString();
            justaddress = address.getText().toString();
            justpass = pass.getText().toString();
            justloc = loca.getSelectedItem().toString();

            justph = ph.getText().toString();
            justuser = user.getText().toString();
            int n = 0;

            if (numF == 1) {
                n = 1;
                ph.setError("number not available");
            }
            if (numft == 1) {
                n = 1;
            }
            if (justname == "" || justname.isEmpty() || justname.equals(" ")) {
                n = 1;
                name.setError("Fill column correctly");
            }
            if (justaddress == "" || justaddress.isEmpty() || justaddress.equals(" ")) {
                n = 1;
                address.setError("Fill column correctly");
            }
            if (justpass == "" || justpass.isEmpty() || justpass.equals(" ")) {
                n = 1;
                pass.setError("Fill column correctly");
            }
            if (justloc == "Your Location" || justloc == null) {
                n = 1;
                Snackbar.make(v, "Please select location", Snackbar.LENGTH_LONG);

            }
            if (n == 1) {
                Snackbar.make(v, "Please fill columns correctly", Snackbar.LENGTH_LONG);
                chk.setEnabled(true);
                progs.setVisibility(View.INVISIBLE);
            } else {

                Map<String, Object> mp = new HashMap<>();

                mp.put("NAME", justname);
                mp.put("ADDRESS", justaddress);
                mp.put("LOCATION", justloc);
                mp.put("CONTACT", justph);
                mp.put("USERNAME", justuser);
                mp.put("PASSWORD", justpass);
                mp.put("ACCTYPE", "SELLER");

                mFire.collection("register").add(mp).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentReference> task) {
                        if (task.isSuccessful()) {
                            chk.setEnabled(true);
                            progs.setVisibility(View.INVISIBLE);
                            Toast.makeText(getApplicationContext(), "Successully saved as Distributor", Toast.LENGTH_LONG).show();

                             startActivity(new Intent(getApplicationContext(), login.class));
                        } else {
                            Snackbar.make(c, "Unable to save profile", BaseTransientBottomBar.LENGTH_SHORT).show();
                            chk.setEnabled(true);
                            progs.setVisibility(View.INVISIBLE);
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Snackbar.make(c, "Something went wrong", BaseTransientBottomBar.LENGTH_SHORT).show();
                        Log.d("ttt", "error:" + e);
                        chk.setEnabled(true);
                        progs.setVisibility(View.INVISIBLE);
                    }
                });

            }
        }
    }


    public void radioChecker(View view) {
        arrayList.clear();
        boolean checked = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.fisher:
                if (checked)
                    //  Toast.makeText(this, "fisher working", Toast.LENGTH_SHORT).show();
                    chk.setEnabled(true);
                    typeac = "fisher";
                name.setVisibility(View.VISIBLE);
                address.setVisibility(View.VISIBLE);
                loca.setVisibility(View.VISIBLE);
                pass.setVisibility(View.VISIBLE);
                id.setVisibility(View.VISIBLE);
                ph.setVisibility(View.VISIBLE);
                user.setVisibility(View.VISIBLE);
                arrayList.add("Your Location");
                arrayList.add("Alappuzha");
                arrayList.add("Ernakulam");
                // arrayList.add( "Idukki");
                arrayList.add("Kannur");
                arrayList.add("Kasaragod");
                arrayList.add("Kollam");
                //  arrayList.add("Kottayam");
                arrayList.add("Kozhikode");
                arrayList.add("Malappuram");
                arrayList.add("Palakkad");
                // arrayList.add("Pathanamthitta");
                arrayList.add("Thiruvananthapuram");
                arrayList.add("Thrissur");
                //  arrayList.add( "Wayanad");

                arrayAdapter.notifyDataSetChanged();
                break;
            case R.id.distributor:
                if (checked)
                    //  Toast.makeText(this, "distributor working", Toast.LENGTH_SHORT).show();
                    chk.setEnabled(true);
                    typeac = "distri";
                name.setVisibility(View.VISIBLE);
                address.setVisibility(View.VISIBLE);
                loca.setVisibility(View.VISIBLE);
                id.setVisibility(View.INVISIBLE);
                ph.setVisibility(View.VISIBLE);
                pass.setVisibility(View.VISIBLE);
                user.setVisibility(View.VISIBLE);
                arrayList.add("Your Location");
                arrayList.add("Alappuzha");
                arrayList.add("Ernakulam");
                arrayList.add("Idukki");
                arrayList.add("Kannur");
                arrayList.add("Kasaragod");
                arrayList.add("Kollam");
                arrayList.add("Kottayam");
                arrayList.add("Kozhikode");
                arrayList.add("Malappuram");
                arrayList.add("Palakkad");
                arrayList.add("Pathanamthitta");
                arrayList.add("Thiruvananthapuram");
                arrayList.add("Thrissur");
                arrayList.add("Wayanad");

                arrayAdapter.notifyDataSetChanged();
                break;
        }
    }

    public class MyEditText extends androidx.appcompat.widget.AppCompatEditText {

        public MyEditText(Context context, AttributeSet attrs) {
            super(context, attrs);
        }

        @Override
        public void setError(CharSequence error, Drawable icon) {
            setCompoundDrawables(null, null, icon, null);
        }
    }



    public boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        assert connectivityManager != null;
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
}
