package com.example.anew;

public class UsrBidData {
   String cudate,sfishrID,spid;

    public String getCudate() {
        return cudate;
    }

    public void setCudate(String cudate) {
        this.cudate = cudate;
    }

    public String getSfishrID() {
        return sfishrID;
    }

    public void setSfishrID(String sfishrID) {
        this.sfishrID = sfishrID;
    }

    public String getSpid() {
        return spid;
    }

    public void setSpid(String spid) {
        this.spid = spid;
    }
}
