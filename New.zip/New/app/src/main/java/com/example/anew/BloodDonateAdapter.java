package com.example.anew;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class BloodDonateAdapter extends RecyclerView.Adapter<BloodDonateAdapter.BloodDonateViewHolder> {
    private ArrayList<UserBidDatas> mBloodDonateList;
    private OnItemClickListener mListener;
    private Context context;
    static String acctype;
  SharedPreferences sharedPreferences;
    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    public static class BloodDonateViewHolder extends RecyclerView.ViewHolder {
        public TextView mTextView1;
        public TextView mTextView2;
        public TextView mTextView3;
        public TextView mTextView4;
        public ImageView mImageView;
        public TextView mTextView6;
        public TextView mTextView5;
       public  Button mButton;
        public BloodDonateViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);
            mTextView1 = itemView.findViewById(R.id.cardtext1);
            mTextView2 = itemView.findViewById(R.id.cardtext2);
            mTextView3 = itemView.findViewById(R.id.cardtext3);
            mTextView4 = itemView.findViewById(R.id.cardtext4);
            mTextView5 = itemView.findViewById(R.id.cardtext5);
            mTextView6 = itemView.findViewById(R.id.cardtext6);
            mImageView = itemView.findViewById(R.id.cardico);
            mButton=itemView.findViewById(R.id.participate);
            mButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }

    public BloodDonateAdapter(ArrayList<UserBidDatas> bloodlist, String acctype) {

       this.acctype = acctype;
        mBloodDonateList = bloodlist;
    }



    @NonNull
    @Override
    public BloodDonateViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_item, parent, false);
        BloodDonateViewHolder bdvh = new BloodDonateViewHolder(v, mListener);
        return bdvh;
    }

    @Override
    public void onBindViewHolder(@NonNull BloodDonateViewHolder holder, int position) {
        UserBidDatas currentitem = mBloodDonateList.get(position);
        Log.d("ffff",""+currentitem.getMinbid());
Glide.with(context).load(currentitem.getImg()).apply(new RequestOptions().transform(new CenterCrop(),new RoundedCorners(30)).skipMemoryCache(true).diskCacheStrategy(DiskCacheStrategy.NONE)).into(holder.mImageView);
        holder.mTextView1.setText(currentitem.getName());
        holder.mTextView2.setText(currentitem.getDiscription());
        holder.mTextView3.setText("₹"+currentitem.getMinbid());
        holder.mTextView4.setText("₹"+currentitem.getBidrate());
        holder.mTextView5.setText(currentitem.getBuyer());
        holder.mTextView6.setText(currentitem.getStatus());
        if(acctype.equals("DISTRIBUTOR"))
        {
           holder.mButton.setVisibility(View.VISIBLE);
        }
    }
    @Override
    public int getItemCount() {
        return mBloodDonateList.size();
    }

}
