package com.example.anew;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;
import static com.example.anew.FisherMainHome.fab;
import static com.example.anew.FisherMainHome.navView;


public class BuyerAddBidFragment extends Fragment {

    private static String sfishrID;
    private static Uri simg;
    private static String sname;
    private static String sdic;
    private static String sminbid;
    private static String spid;
    private static String cudate;
    private static String buyerid;
    private static String buyername;
    private static int minbidrate, maxbidrate;
    private View view;
    ImageView timg;
    DatabaseReference dbref;
    FirebaseDatabase rdb;
    Button saver;
    SharedPreferences sharedPreferences;
    TextView txtname, txtdic, txtminbid, txtbuyer, txtcurate, txtstatus, inputamd, endtimer;

    BuyerAddBidFragment() {

    }

    BuyerAddBidFragment(Uri img, String fid, String name, String disc, String minbid, String pid, String datee) {
        simg = img;
        sfishrID = fid;
        sname = name;
        sdic = disc;
        sminbid = minbid;
        minbidrate = Integer.parseInt(minbid);
        spid = pid;
        cudate = datee;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_buyer_add_bid, container, false);
        Log.d("buyer", cudate + ":" + sfishrID + ":" + spid);
        dbref = FirebaseDatabase.getInstance().getReference().child("BID").child(cudate).child(sfishrID).child(spid);
        rdb = FirebaseDatabase.getInstance();
        sharedPreferences = getActivity().getSharedPreferences("LOCAL", MODE_PRIVATE);
        buyerid = sharedPreferences.getString("ID", null);
        buyername = sharedPreferences.getString("NAME", null);
        fab.setVisibility(View.INVISIBLE);
        navView.setVisibility(View.INVISIBLE);
        txtname = view.findViewById(R.id.pname);
        txtdic = view.findViewById(R.id.pdisc);
        timg = view.findViewById(R.id.fishimg);
        saver = view.findViewById(R.id.bidsave);
        inputamd = view.findViewById(R.id.scrlch);
        txtminbid = view.findViewById(R.id.pminbid);
        txtcurate = view.findViewById(R.id.pcurrentbid);
        txtbuyer = view.findViewById(R.id.pcubuyer);
        endtimer = view.findViewById(R.id.endtime);
        txtstatus = view.findViewById(R.id.pstatus);
        txtname.setText("Product name: " + sname);
        txtdic.setText("Discription: " + sdic);
        txtminbid.setText("Minimum rate: " + sminbid);
        Picasso.with(getContext()).load(simg).into(timg);
        dbref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                if (dataSnapshot.exists()) {
                    BidAddContent bid;
                    bid = dataSnapshot.getValue(BidAddContent.class);

                    //   String text = ds.child("text").getValue(String.class);
                    int h = 0, m = 0;
                    String bidrate = null;
                    String status = null;
                    String time = null;
                    String buyer = null;


                    //    Log.d("snapshot", "child snapshot name" + bid.getName());
                    //     Log.d("snapshot", "child snapshot status" + status);
                    status = bid.getStatus();
                    bidrate = bid.getBidrate();
                    time = bid.getTime();
                    buyer = bid.getBuyer();
                    if (status.contains("open")) {
                        String[] vt = time.split(":");
                        h = Integer.parseInt(vt[0]);
                        m = Integer.parseInt(vt[1]);
                        h = h + 1;
                        maxbidrate = Integer.parseInt(bidrate);
                        txtcurate.setText("Current bid rate: " + bidrate);
                        txtbuyer.setText("Buyer: " + buyer);
                        txtstatus.setText("Status: " + status);
                        endtimer.setText("Bid end time: " + h + ":" + m);
                    } else {
                        maxbidrate = Integer.parseInt(bidrate);
                        txtcurate.setText("Current rate: " + bidrate);
                        txtbuyer.setText("Buyer: " + buyer);
                        txtstatus.setText("Status: " + status);
                        endtimer.setText("Bid end time: " + h + ":" + m);
                        inputamd.setInputType(InputType.TYPE_NULL);
                        inputamd.setFocusable(false);
                        saver.setEnabled(false);
                    }

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.d("snapshot", "ERROR.....r" + databaseError);
            }
        });
        saver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertAmdByBuyer();
            }
        });
        return view;
    }


    private void insertAmdByBuyer() {

        final int usrbidrate = Integer.parseInt(inputamd.getText().toString());
        if (usrbidrate == 0) {
            Toast.makeText(getContext(), "please enter amount", Toast.LENGTH_SHORT).show();
        } else if (usrbidrate < minbidrate) {
            Toast.makeText(getContext(), "must be greater than minimum bid rate", Toast.LENGTH_SHORT).show();
        } else {
            if (usrbidrate > maxbidrate) {
                if (isNetworkAvailable() == true) {
                    Log.d("buyer", "inner ethi");
                    Map<String, Object> map1 = new HashMap<>();
                    map1.put("buyid", buyerid);
                    map1.put("buyer", buyername);
                    map1.put("bidrate", String.valueOf(usrbidrate));
                    rdb.getReference().child("BID").child(cudate).child(sfishrID).child(spid).updateChildren(map1).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            UsrBidData usrBidData = new UsrBidData();
                            usrBidData.setCudate(cudate);
                            usrBidData.setSfishrID(sfishrID);
                            usrBidData.setSpid(spid);
                            rdb.getReference().child("history").child(buyerid).child(spid).setValue(usrBidData).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Snackbar.make(view, "Bid saved sucessfully", Snackbar.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(getActivity(), "Unable to add this bid to history", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Snackbar.make(view, "Something went wrong", Snackbar.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    Toast.makeText(getContext(), "must be greater than current bid rate", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), "must be greater than current bid rate", Toast.LENGTH_SHORT).show();
            }
        }

    }

    public boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        assert connectivityManager != null;
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
}
