package com.example.anew.ui.notifications;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.anew.BidAddContent;
import com.example.anew.BloodDonateAdapter;
import com.example.anew.UserBidDatas;
import com.example.anew.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import static androidx.constraintlayout.widget.Constraints.TAG;
import static com.example.anew.FisherMainHome.fab;
import static com.example.anew.FisherMainHome.navView;

public class NotificationsFragment extends Fragment {
    RecyclerView bloodlist;
    private BloodDonateAdapter mAdaptor;
    static String currentDate1;
    static boolean bb=true;
    static  int c=0;
    ProgressBar prog;
    DatabaseReference dbref;
    FirebaseDatabase rdb;
    int cumin=0,cusec=0,h1=0,s1=0;
    SharedPreferences sharedPreferences;
    private RecyclerView.LayoutManager mLayoutManager;
    ArrayList<UserBidDatas> bloodDonatelist;
    private NotificationsViewModel notificationsViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        notificationsViewModel =
                ViewModelProviders.of(this).get(NotificationsViewModel.class);
        View view = inflater.inflate(R.layout.fragment_notifications, container, false);
        fab.setVisibility(View.VISIBLE);
        navView.setVisibility(View.VISIBLE);
        bb=true;
        prog=view.findViewById(R.id.proger);
        currentDate1 = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        navView.getMenu().findItem(R.id.navigation_notifications).setChecked(true);
        sharedPreferences=getContext().getSharedPreferences("LOCAL", Context.MODE_PRIVATE);
        final String currentDate1 = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        String usrid=sharedPreferences.getString("ID",null);
        dbref= FirebaseDatabase.getInstance().getReference().child("BID").child(currentDate1).child(usrid);
        bloodlist=view.findViewById(R.id.fisherrecyclerView);
    rdb=FirebaseDatabase.getInstance();
        bloodDonatelist = new ArrayList<>();
        bloodlist.setHasFixedSize(true);
        mLayoutManager=new LinearLayoutManager(getContext());
        bloodlist.setLayoutManager(mLayoutManager);
        mAdaptor=new BloodDonateAdapter(bloodDonatelist,"FISHER");
        bloodlist.setAdapter(mAdaptor);

        dbref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                bloodDonatelist.clear();


                    for(DataSnapshot childsnapshot: dataSnapshot.getChildren()) {
                      if(childsnapshot.exists())
                        {
                        BidAddContent bid = childsnapshot.getValue(BidAddContent.class);
                        String name = null;
                        String discription = null;
                        String minbid = null;
                        Uri img = null;
                        String bidrate = null;
                        String status = null;
                        String time = null;
                        String buyer = null;
                        String productid = null;
                        String fisherid = null;
                        status = bid.getStatus();
                        //    Log.d("snapshot", "child snapshot name" + bid.getName());
                        //     Log.d("snapshot", "child snapshot status" + status);
                        name = bid.getName();
                        discription = bid.getDiscription();
                        minbid = bid.getMinbid();
                        img = Uri.parse(bid.getImg());
                        bidrate = bid.getBidrate();
                        time = bid.getTime();
                        buyer = bid.getBuyer();

                        productid = bid.getProductid();
                        fisherid = bid.getFisherid();

                        Log.d("snapshot", "child snapshot name" + bid.getName());
                        Log.d("snapshot", "child snapshot status" + status);
                        bloodDonatelist.add(new UserBidDatas(name, discription, minbid, img, bidrate, status, time, buyer, productid, fisherid));

                    }
                    }

         //   new LongOperation().execute();
                betch();
                mAdaptor.notifyDataSetChanged();
                c= bloodDonatelist.size();
                Log.d("snapshot", "blooddonatesize" + c);
                if(c==0)
                {
                    prog.setVisibility(View.INVISIBLE);
                }
                else
                {
                    prog.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.d("snapshot","ERROR.....r"+databaseError);
            }
        });
        Log.d("snapshot","daddaadadadda..........................");
        return view;
    }
    @Override
    public void onPause() {
        bb=false;
        super.onPause();
    }

    @Override
    public void onResume() {
        bb=true;
        //new LongOperation().execute();
        super.onResume();
        navView.getMenu().findItem(R.id.navigation_notifications).setChecked(true);
        betch();
    }
 public void betch()
    {
        final Handler handler = new Handler();
        final int delay = 1000; //milliseconds

        handler.postDelayed(new Runnable() {
            public void run() {
                if(bb==true) {
                    dbFun();
                    handler.postDelayed(this, delay);
                }
            }
        }, delay);
    }





    public void dbFun()
    {

        final String currentTime = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        String[] Timer1=currentTime.split(":");
        cumin=Integer.parseInt(Timer1[0]);
        cusec=Integer.parseInt(Timer1[1]);
        for(int i=0;i<c;i++) {
            String fishrID = bloodDonatelist.get(i).getFisherid();
            String productid = bloodDonatelist.get(i).getProductid();
            String stat=bloodDonatelist.get(i).getStatus();
            String time = bloodDonatelist.get(i).getTime();
            String[] splitter = time.split(":");
            int dbminute = Integer.parseInt(splitter[0]);
            int dbsec = Integer.parseInt(splitter[1]);
            dbminute = dbminute + 1;
            Map<String, Object> map1 = new HashMap<>();
            map1.put("status", "close");
            Log.d("snapshot", "current :" + cumin + ":" + cusec + " dbtime  :" + dbminute + ":" + dbsec);
            if(stat.equals("open"))
            {  Log.d(TAG, "sucess hfsjdkhf..............: ");
            if (cumin > dbminute) {

                rdb.getReference().child("BID").child(currentDate1).child(fishrID).child(productid).updateChildren(map1).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "sucess 1..............: ");
                        SystemClock.sleep(1000);
betch();

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d(TAG, "exception 1..............: " + e);
                        SystemClock.sleep(1000);
betch();
                    }
                });

            } else if (cumin == dbminute) {
                if (cusec >= dbsec) {
                    rdb.getReference().child("BID").child(currentDate1).child(fishrID).child(productid).updateChildren(map1).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d(TAG, "sucess 1..............: ");
                            SystemClock.sleep(1000);
betch();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.d(TAG, "exception 1..............: " + e);
                            SystemClock.sleep(1000);
betch();
                        }
                    });
                }

            }
        }
        }
    }





    /////////////////////////////////////////////////


    private class LongOperation extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... params) {
            while(bb){
                try {
                    Log.d("snapshot", "background");

                 dbFun();
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }


            return null;
        }



        @Override
        protected void onPreExecute() {
        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }



    }


}
