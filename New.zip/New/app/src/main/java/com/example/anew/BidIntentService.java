package com.example.anew;

import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.PowerManager;
import android.os.SystemClock;
import android.text.format.Time;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;


import static androidx.core.app.NotificationManagerCompat.IMPORTANCE_LOW;
import static com.example.anew.AddBidFragment.productidd;
import static com.example.anew.App.CHANNEL_ID;
import static com.example.anew.App.manager;

public class BidIntentService extends IntentService {
    private static final String TAG = "ExampleIntentService";
    Notification notification;
FirebaseDatabase rdb;
   int gcnt=0;
    private static String[] sss=new String[100];
    private static  int k=0,j=0;
    private static String usrid;
    SharedPreferences sharedPreferences;
    CountDownTimer cnt; Context context;
    private PowerManager.WakeLock wakeLock;
    private static String MainTime;
public  static long timeseconds;
int cunter=1;
    NotificationCompat.Builder notificationBuilder;
    public BidIntentService() {
        super("ExampleIntentService");
        setIntentRedelivery(true);
    }
    /////////////////////////////////////////////////



    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate");
        sharedPreferences=getSharedPreferences("LOCAL", Context.MODE_PRIVATE);
      usrid=sharedPreferences.getString("ID",null);
        rdb=FirebaseDatabase.getInstance();
        PowerManager powerManager;
        powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                "ExampleApp:Wakelock");
        wakeLock.acquire();
        Log.d(TAG, "Wakelock acquired");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            notificationBuilder = new NotificationCompat.Builder(this, CHANNEL_ID);
            notification = notificationBuilder.setOngoing(true)
                    .setContentTitle("New Bid")
                    .setContentText("Starting....")
                    .setSmallIcon(R.drawable.ic_bidding)
                    .build();

            startForeground(1, notification);

        }
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        Log.d(TAG, "onHandleIntent");
        j = j + 1;
        gcnt = 0;
        final Map<String, Object> map = new HashMap<>();
        MainTime = sss[j];  // product id
        final String currentDate1 = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        String currentTime1 = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        Log.d(TAG, "MAINOKIKKKKD..............: " + MainTime);
        map.put("status", "open");
        map.put("time", currentTime1);
        rdb.getReference().child("BID").child(currentDate1).child(usrid).child(MainTime).updateChildren(map).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                gcnt = 1;
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.d(TAG, "exception 2..............: " + e);
            }
        });
        SystemClock.sleep(5000);
        if(gcnt==1)
        {
        for (int i = 1; i <= 3600; i++) {
            timeseconds =  3600- i;
            Log.d(TAG, " - " + i);
            updateTimer();
            if (i == 3600) {


                Map<String, Object> map1 = new HashMap<>();
                map1.put("status", "close");
                rdb.getReference().child("BID").child(currentDate1).child(usrid).child(MainTime).updateChildren(map1).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "sucess 1..............: ");

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d(TAG, "exception 1..............: " + e);
                    }
                });
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    notification = notificationBuilder.setOngoing(true)
                            .setSmallIcon(R.drawable.ic_bidding)
                            .setContentTitle("Bid")
                            .setContentText("Bid Completed")
                            .setPriority(IMPORTANCE_LOW)
                            .build();
                    manager.notify(1, notification);
                }

            }
            SystemClock.sleep(1000);
        }
    }
    }

    @Override
    public void onDestroy() {

          super.onDestroy();
          Log.d(TAG, "onDestroy");

          wakeLock.release();
          Log.d(TAG, "Wakelock released");

    }

    public void updateTimer()
    {

        int minutes= (int) (timeseconds/60);
        int seconds= (int) (timeseconds%60);
        String timeleft;
        timeleft=""+minutes;
        timeleft+=":";
        if(seconds<10) timeleft+="0";
        timeleft+=seconds;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notification = notificationBuilder.setOngoing(true)
                    .setSmallIcon(R.drawable.ic_bidding)
                    .setContentTitle("Bid")
                    .setContentText("time :"+timeleft)
                    .setSound(null)
                    .build();
            manager.notify(1,notification);
        }

        if(timeleft=="0:00")
        {Log.d("tttf","bidendd................................................................");
            biddend();
        }

//return timeleft;
    }
    public void biddend()
    {
        Log.d("tttf","bidendd................................................................");

        cunter=0;


        super.onDestroy();
        Log.d(TAG, "onDestroy");

        wakeLock.release();

        Log.d(TAG, "Wakelock released");
    }

    public boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        assert connectivityManager != null;
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
    public void idCintainer(String idd)
    {   k=k+1;
        sss[k]=""+idd;
        Log.d("ttt",""+sss[k]);
    }


    /////////////////////////////////////////////////////
/*
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate");

        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                "ExampleApp:Wakelock");
        wakeLock.acquire();
        Log.d(TAG, "Wakelock acquired");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationBuilder = new NotificationCompat.Builder(this, CHANNEL_ID);
            notification = notificationBuilder.setOngoing(true)
                    .setSmallIcon(R.drawable.ic_bidding)
                    .setContentTitle("Bid")
                    .setContentText("started")

                    .build();
            startForeground(2,notification);
        }
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        Log.d(TAG, "onHandleIntent");
        final String input = intent.getStringExtra("inputExtra");
        cnt = new CountDownTimer(timeinmillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                Log.d("tttf", "mmmmm");

                timeinmillis = millisUntilFinished;
                Log.d("tttf", "loop:" + timeinmillis);

              updateTimer();
            }

            @Override
            public void onFinish() {
                notification = notificationBuilder.setOngoing(true)
                        .setSmallIcon(R.drawable.ic_bidding)
                        .setContentTitle("Bid")
                        .setContentText("Completed")
                        .build();
                startForeground(2,notification);
                biddend();
            }
        }.start();
    }
    @Override
    public void onDestroy() {
     if(cunter==0) {
         super.onDestroy();
         Log.d(TAG, "onDestroy");

         wakeLock.release();
         Log.d(TAG, "Wakelock released");
     }

    }


    public void updateTimer()
    {
        int minutes= (int) (timeseconds/60);
        int seconds= (int) (timeseconds%60);
        String timeleft;
        timeleft=""+minutes;
        timeleft+=":";
        if(seconds<10) timeleft+="0";
        timeleft+=seconds;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notification = notificationBuilder.setOngoing(true)
                    .setSmallIcon(R.drawable.ic_bidding)
                    .setContentTitle("time :"+timeleft)
                    .build();
            startForeground(2,notification);
        }

        if(timeleft=="0:00")
        {
            biddend();
        }


//return timeleft;
    }
    public void biddend()
    {
        Log.d("tttf","bidendd................................................................");

        cunter=0;


        super.onDestroy();
        Log.d(TAG, "onDestroy");
closeEverything();
        wakeLock.release();

        Log.d(TAG, "Wakelock released");
    }
    public void closeEverything()
    {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(true);
        }

        Log.d(TAG, "Wakelock released");
    }
    */

}
