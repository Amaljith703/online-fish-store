package com.example.anew;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Pie;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static com.example.anew.FisherMainHome.fab;
import static com.example.anew.FisherMainHome.navView;


public class DistDashStockFragment extends Fragment {
    AnyChartView anyChartView;
    FirebaseDatabase rdb;
    ArrayList<StockItem> stk;
    List<DataEntry> dataEntries;
    ArrayList fishes = new ArrayList();
    RecyclerView rs;
    StockAdapter mAdapter;
    Pie pie;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_dist_dash_stock, container, false);
        fab.setVisibility(View.INVISIBLE);
        navView.getMenu().findItem(R.id.navigation_dashboard).setChecked(true);
        rdb = FirebaseDatabase.getInstance();
        rs=view.findViewById(R.id.stockrecycler);
        rs.setLayoutManager(new LinearLayoutManager(getContext()));
        anyChartView=view.findViewById(R.id.piechart);
        stk = new ArrayList<>();
        mAdapter=new StockAdapter(stk);
        rs.setAdapter(mAdapter);
        dataEntries=new ArrayList<>();
        pie= AnyChart.pie();
        anyChartView.setChart(pie);
        getDatasForAoto();
        anyChartView=view.findViewById(R.id.piechart);

        return view;
    }

    @Override
    public void onResume() {
        navView.getMenu().findItem(R.id.navigation_dashboard).setChecked(true);
        fab.setVisibility(View.INVISIBLE);
        super.onResume();
        getDatasForAoto();
    }

    public void getDatasForAoto() {
        Calendar cl = Calendar.getInstance();
        String date = "" + (cl.get(Calendar.DAY_OF_MONTH));
        date = date + "-" + cl.get(Calendar.MONTH) + "-" + cl.get(Calendar.YEAR);
        Log.d("logs", date);
        rdb.getReference().child("STOCK").child(date).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                fishes.clear();
                stk.clear();
                dataEntries.clear();
                for (DataSnapshot d : dataSnapshot.getChildren()) {
                    if (d.exists()) {
                        StockItem ds = d.getValue(StockItem.class);
                        String name = null;
                        name = ds.getName();
                        String id = null;
                        id = ds.getIds();
                        String date = null;
                        date = ds.getDate();
                        float qty = 0;
                        qty = ds.getQty();
                        String loca = null;
                        loca = ds.getLocation();
                        stk.add(new StockItem(date, id, name, loca, qty));
                        fishes.add(name);
                        dataEntries.add(new ValueDataEntry(name,qty));
                    }
                }
                mAdapter.insertAll(stk);
                mAdapter.notifyDataSetChanged();
                pie.data(dataEntries);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
