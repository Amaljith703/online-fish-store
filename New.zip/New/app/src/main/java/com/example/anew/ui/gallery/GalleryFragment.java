package com.example.anew.ui.gallery;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.anew.CreateAcc;
import com.example.anew.R;
import com.example.anew.login;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.WriteBatch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;
import static com.example.anew.FisherMainHome.fab;
import static com.example.anew.FisherMainHome.navView;
import static java.lang.Void.TYPE;

public class GalleryFragment extends Fragment {
SharedPreferences sharedPreferences;
SharedPreferences.Editor editor;
FirebaseFirestore mFire;
    ArrayAdapter<String> arrayAdapter;
    ProgressBar prs;
    private GalleryViewModel galleryViewModel;
Button button;
ArrayList arrayList=new ArrayList<String>();
FirebaseFirestore f;
    EditText name, address, id, ph, pass, user;
EditText txtloc;Spinner loc;
    int numF = 0, numff = 0,cnt=0, numft = 0;
    String justid = null, justph = null, justuser = null, justname = null, justaddress = null, justpass = null, justloc = null;
private  static String nam=null,usernamer=null,passer=null,addresser=null,cintacter=null,locer=null,typer=null,fiddd=null;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        galleryViewModel =
                ViewModelProviders.of(this).get(GalleryViewModel.class);

        final View root = inflater.inflate(R.layout.fragment_gallery, container, false);
        navView.setVisibility(View.INVISIBLE);
        fab.setVisibility(View.INVISIBLE);
        loc= root.findViewById(R.id.comlocspin);

        f = FirebaseFirestore.getInstance();
        txtloc=root.findViewById(R.id.txtloc);
        prs=root.findViewById(R.id.progesss);
        prs.setVisibility(View.INVISIBLE);
name=root.findViewById(R.id.comname);
user= root.findViewById(R.id.comusernme);
pass= root.findViewById(R.id.passworder);
address= root.findViewById(R.id.comaddress);
ph= root.findViewById(R.id.contacter);
button= root.findViewById(R.id.eediter);

name.setInputType(InputType.TYPE_NULL);
user.setInputType(InputType.TYPE_NULL);

address.setInputType(InputType.TYPE_NULL);
ph.setInputType(InputType.TYPE_NULL);

loc.setVisibility(View.INVISIBLE);
        getDBData();
//////////////////////////////////////////////////////

        user.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int length = s.length();
                String name = s.toString();
                Log.d("dddd","usrnm:txt"+name+",db:"+nam);
                if(usernamer.equals(name))
                {
                    numft = 0;
                }
               else if (length < 3) {
                    user.setError("minimum 3 charctors");
                    numft = 1;
                } else {

                    numft = 0;
                    mFire.collection("register").whereEqualTo("USERNAME", name).addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                            for (DocumentChange d : queryDocumentSnapshots.getDocumentChanges()) {
                                if (d.getType() == DocumentChange.Type.ADDED) {
                                    if (d.getDocument().exists()) {
                                        user.setError("username not available");

                                        numft = 1;
                                    } else {
                                        Toast.makeText(getContext(), "yess", Toast.LENGTH_SHORT).show();

                                    }
                                }
                            }
                        }
                    });
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

///////////////////////////////////////////////////////

        ph.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int length = s.length();
                String name = s.toString();
                Log.d("dddd","ph:txt"+name+",db:"+cintacter);
                if(name.equals(cintacter))
                {
                    numF = 0;
                }
               else if (length < 10) {
                    ph.setError("10 digit contact number");
                    numF = 1;
                } else {
                    numF = 0;
                    mFire.collection("register").whereEqualTo("CONTACT", name).addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                            for (DocumentChange d : queryDocumentSnapshots.getDocumentChanges()) {
                                if (d.getType() == DocumentChange.Type.ADDED) {
                                    if (d.getDocument().exists()) {
                                        ph.setError("number not available");
                                        //  Toast.makeText(CreateAcc.this, "no", Toast.LENGTH_SHORT).show();
                                        numF = 1;
                                    } else {
                                        //  Toast.makeText(CreateAcc.this, "yess", Toast.LENGTH_SHORT).show();

                                    }
                                }
                            }
                        }
                    });
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

////////////////////////////////////////////////////////
button.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        String fndbt=button.getText().toString();
        if (fndbt=="Save")
        { button.setText("Edit");
        numff=0;
          numff=  validateEveryThi(root);


            Log.d("ggg", "bt 1 :"+fndbt);
        }
        else
        {pass.setVisibility(View.VISIBLE);
        txtloc.setVisibility(View.INVISIBLE);
            loc.setVisibility(View.VISIBLE);
            name.setInputType(InputType.TYPE_CLASS_TEXT);
            user.setInputType(InputType.TYPE_CLASS_TEXT);
            address.setInputType(InputType.TYPE_CLASS_TEXT);
            ph.setInputType(InputType.TYPE_CLASS_TEXT);
            name.setFocusable(true);
            user.setFocusable(true);
            address.setFocusable(true);
            ph.setFocusable(true);
            Log.d("ggg", "bt 2 :"+fndbt);
            button.setText("Save");

        }

    }
});
        arrayList = new ArrayList<>();
        String st=sharedPreferences.getString("ACCTYPE", null);
        radioChecker(st);
        arrayAdapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, arrayList);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        loc.setAdapter(arrayAdapter);

        return root;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mFire = FirebaseFirestore.getInstance();
        sharedPreferences=getActivity().getSharedPreferences("LOCAL", MODE_PRIVATE);
        editor=sharedPreferences.edit();
    }

    private void getDBData()
    {
      /*  editor.putString("ID",fid);
        editor.putString("USERNAME", usr);
        editor.putString("PASSWORD", psd);
        editor.putString("ACCTYPE", acctype);
        editor.putString("NAME",nm);
        editor.apply();

            DocumentReference min = f.collection("name").document(numbr);
    batch.update(min, "NAME", nme);
    batch.update(min, "GMAIL", mail);

        */
String uidd=sharedPreferences.getString("ID", null);
        Log.d("profile","uidd:"+uidd);
        if(uidd!=null)
        {
            mFire.collection("register").document(uidd).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                @Override
                public void onSuccess(DocumentSnapshot documentSnapshot) {

                   addresser= documentSnapshot.getString("ADDRESS");
                    cintacter=documentSnapshot.getString("CONTACT");
                   nam= documentSnapshot.getString("NAME");
                    usernamer=documentSnapshot.getString("USERNAME");
                   locer= documentSnapshot.getString("LOCATION");
                    passer=documentSnapshot.getString("PASSWORD");
                   typer= documentSnapshot.getString("ACCTYPE");
                   Log.d("profile","nam :"+nam+" addresss :"+addresser+"");

                    name.setText(nam);
                    user.setText(usernamer);
                    pass.setVisibility(View.INVISIBLE);
                    pass.setText(passer);
                    txtloc.setText(locer);
                    address.setText(addresser);
                    ph.setText(cintacter);
                   fiddd=documentSnapshot.getId();

                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                }
            });
        }
    }

    public void radioChecker(String checked) {
        arrayList.clear();
        Log.d("dddd","+++"+checked);
        if (checked.contains("FISHER"))
        {
            //  Toast.makeText(this, "fisher working", Toast.LENGTH_SHORT).show();
            Log.d("dddd","+++ knappe2");
        arrayList.add("Your Location");
        arrayList.add("Alappuzha");
        arrayList.add("Ernakulam");
        // arrayList.add( "Idukki");
        arrayList.add("Kannur");
        arrayList.add("Kasaragod");
        arrayList.add("Kollam");
        //  arrayList.add("Kottayam");
        arrayList.add("Kozhikode");
        arrayList.add("Malappuram");
        arrayList.add("Palakkad");
        // arrayList.add("Pathanamthitta");
        arrayList.add("Thiruvananthapuram");
        arrayList.add("Thrissur");
        //  arrayList.add( "Wayanad");

            Log.d("dddd","+++"+arrayList.size());
    }
                if (checked.contains("SELLER"))
                {
                    //  Toast.makeText(this, "distributor working", Toast.LENGTH_SHORT).show();

                arrayList.add("Your Location");
                arrayList.add("Alappuzha");
                arrayList.add("Ernakulam");
                arrayList.add("Idukki");
                arrayList.add("Kannur");
                arrayList.add("Kasaragod");
                arrayList.add("Kollam");
                arrayList.add("Kottayam");
                arrayList.add("Kozhikode");
                arrayList.add("Malappuram");
                arrayList.add("Palakkad");
                arrayList.add("Pathanamthitta");
                arrayList.add("Thiruvananthapuram");
                arrayList.add("Thrissur");
                arrayList.add("Wayanad");
                    Log.d("dddd","+++ knappe2");
                    Log.d("dddd","+++"+arrayList.size());



        }
    }

    private int validateEveryThi(View v) {

        final View c = v;
        prs.setVisibility(View.VISIBLE);
         button.setEnabled(false);
            justname = name.getText().toString().trim();
            justaddress = address.getText().toString().trim();
            justpass = pass.getText().toString().trim();
            justloc = loc.getSelectedItem().toString().trim();
            justph = ph.getText().toString().trim();
            justuser = user.getText().toString().trim();
            int n = 0;

            if (numF == 1) {
                n = 1;
                ph.setError("number not available");
                Log.d("ttt", "number error");

            }if(!isNetworkAvailable())
        {
            n = 1;
            Snackbar.make(c,"Please enable network",400).show();
        }
            if (numft == 1) {
                n = 1;
            }
            if (justname == "" || justname.isEmpty() || justname.equals(" ")) {
                n = 1;
                Log.d("ttt", "name error");
                name.setError("Fill column correctly");
            }
            if (justaddress == "" || justaddress.isEmpty() || justaddress.equals(" ")) {
                n = 1;
                address.setError("Fill column correctly");
                Log.d("ttt", "address error");
            }
            if (justpass == "" || justpass.isEmpty() || justpass.equals(" ")) {
                n = 1;
                pass.setError("Fill column correctly");
                Log.d("ttt", "pass error");
            }
            if (justloc == "Your Location" || justloc == null) {
                n = 1;
                Snackbar.make(c, "Please select location", Snackbar.LENGTH_SHORT).show();
            }
            if (n == 1) {
                prs.setVisibility(View.INVISIBLE);
                button.setEnabled(true);
                Snackbar.make(c, "Please fill columns correctly", Snackbar.LENGTH_SHORT).show();
                Log.d("ttt", "somewhere error");
            } else {
                    cnt=0;
                WriteBatch batch = f.batch();
                DocumentReference min = f.collection("register").document(fiddd);
                batch.update(min, "NAME", justname);
                batch.update(min, "ADDRESS", justaddress);
                batch.update(min, "LOCATION", justloc);
                batch.update(min, "CONTACT", justph);
                batch.update(min, "USERNAME", justuser);
                batch.update(min, "PASSWORD", justpass);
     batch.commit().addOnSuccessListener(new OnSuccessListener<Void>() {
         @Override
         public void onSuccess(Void aVoid) {

             txtloc.setVisibility(View.VISIBLE);
             loc.setVisibility(View.INVISIBLE);
             pass.setVisibility(View.INVISIBLE);
             name.setInputType(InputType.TYPE_NULL);
             user.setInputType(InputType.TYPE_NULL);
             address.setInputType(InputType.TYPE_NULL);
             ph.setInputType(InputType.TYPE_NULL);
             name.setFocusable(false);
             user.setFocusable(false);
             address.setFocusable(false);
             ph.setFocusable(false);
             editor.putString("USERNAME", justuser);
             editor.putString("PASSWORD", justpass);
             editor.putString("NAME",justname);
             editor.apply();
             Toast.makeText(getContext(), "Saved", Toast.LENGTH_SHORT).show();
             prs.setVisibility(View.INVISIBLE);
             button.setEnabled(true);
         }
     })
             .addOnFailureListener(new OnFailureListener() {
                 @Override
                 public void onFailure(@NonNull Exception e) {
                    Snackbar.make(c,"Something went wrong  try again!",Snackbar.LENGTH_LONG).show();
                     txtloc.setVisibility(View.VISIBLE);
                     loc.setVisibility(View.INVISIBLE);
                     pass.setVisibility(View.INVISIBLE);
                     name.setInputType(InputType.TYPE_NULL);

                     user.setInputType(InputType.TYPE_NULL);

                     address.setInputType(InputType.TYPE_NULL);

                     ph.setInputType(InputType.TYPE_NULL);
                     name.setFocusable(false);
                     user.setFocusable(false);
                     address.setFocusable(false);
                     ph.setFocusable(false);
                     prs.setVisibility(View.INVISIBLE);
                     button.setEnabled(true);
                   cnt=1;
                 }
             });
            }
return  cnt;
    }
    public boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        assert connectivityManager != null;
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


}
