package com.example.anew;

public class StockItem {
    private String ids;
    private String name;
    private float qty;
    private String location;
    private String date;

    public StockItem()
    {

    }
    public StockItem(String date,String ids,String name,String location,float qty)
    {
        this.date=date;
        this.ids=ids;
        this.name=name;
        this.location=location;
        this.qty=qty;
    }
    public String getIds() {
        return ids;
    }

    public void setIds(String ids) {
        this.ids = ids;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getQty() {
        return qty;
    }

    public void setQty(float qty) {
        this.qty = qty;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
