package com.example.anew.ui.home;

import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.anew.UserBidDatas;
import com.example.anew.FishPriceAdapter;
import com.example.anew.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import static com.example.anew.FisherMainHome.fab;
import static com.example.anew.FisherMainHome.navView;

public class HomeFragment extends Fragment {
    RecyclerView rs;
    FishPriceAdapter mAdapter;
    FirebaseDatabase rdb;
    private ArrayList<UserBidDatas> arrayls;
    private HomeViewModel homeViewModel;
    TextView txt;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_home, container, false);
        navView.setVisibility(View.VISIBLE);
        fab.setVisibility(View.INVISIBLE);
        arrayls=new ArrayList<>();
        rs=root.findViewById(R.id.fishrecycler);
        navView.getMenu().findItem(R.id.navigation_home).setChecked(true);
        rdb=FirebaseDatabase.getInstance();
        rs.setLayoutManager(new LinearLayoutManager(getContext()));
        mAdapter=new FishPriceAdapter(arrayls);
        rs.setAdapter(mAdapter);
        getDataorThis();
        return root;
    }


    private void getDataorThis()
    {

        rdb.getReference().child("fishrate").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                arrayls.clear();
                if(dataSnapshot.exists()) {
                    for (DataSnapshot childsnapshot : dataSnapshot.getChildren()) {
                        if(childsnapshot.exists())
                        {
                            UserBidDatas bs=new UserBidDatas();
                            String ider=childsnapshot.child("ids").getValue(String.class);
                            Uri img= Uri.parse(childsnapshot.child("imgs").getValue(String.class));
                            String name=childsnapshot.child("name").getValue(String.class);
                            String price=childsnapshot.child("price").getValue(String.class);
                            Log.d("mmm","ider "+ider);
                            Log.d("mmm","name "+name);
                            Log.d("mmm","price "+price);
                            arrayls.add(new UserBidDatas().insertdata(ider,name,price,img));
                        }

                    }
            mAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.d("gggg","database :"+databaseError.getMessage());
            }
        });


    }


    @Override
    public void onResume() {
        navView.getMenu().findItem(R.id.navigation_home).setChecked(true);
        getDataorThis();
        super.onResume();
    }
}
