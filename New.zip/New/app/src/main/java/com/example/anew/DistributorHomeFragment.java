package com.example.anew;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import static com.example.anew.FisherMainHome.fab;
import static com.example.anew.FisherMainHome.navView;
public class DistributorHomeFragment extends Fragment {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        fab.setVisibility(View.INVISIBLE);
        navView.getMenu().findItem(R.id.navigation_home).setChecked(true);
      View view= inflater.inflate(R.layout.fragment_distributor_home, container, false);
        return view;

    }
}
