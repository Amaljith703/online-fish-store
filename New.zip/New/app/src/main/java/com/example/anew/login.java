package com.example.anew;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

public class login extends AppCompatActivity {
    Button log;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    EditText name, pass;
    private String acctype = null,nm=null,fid=null;
    FirebaseFirestore mFire;
    String usr = null, psd = null;
    private int n = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        log = findViewById(R.id.button);
        mFire = FirebaseFirestore.getInstance();

        name = findViewById(R.id.editText);
        pass = findViewById(R.id.editText2);
        sharedPreferences = this.getSharedPreferences("LOCAL", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final View vs = v;
                n = 0;

                usr = name.getText().toString().trim();
                psd = pass.getText().toString().trim();
                if (usr.isEmpty() || usr == "" || usr == " ") {
                    Snackbar.make(vs, "Inavlid username or password", Snackbar.LENGTH_SHORT).show();
                } else if (psd.isEmpty() || psd == "" || psd == " ") {
                    Snackbar.make(vs, "Inavlid username or password", Snackbar.LENGTH_SHORT).show();
                } else {
                    mFire.collection("register").whereEqualTo("USERNAME", usr).whereEqualTo("PASSWORD", psd).addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                            for (DocumentChange d : queryDocumentSnapshots.getDocumentChanges()) {
                                if (d.getType() == DocumentChange.Type.ADDED) {
                                    if (d.getDocument().exists()) {
                                        n = 1;
                                        fid=d.getDocument().getId();
                                        acctype = d.getDocument().get("ACCTYPE").toString();
                                        nm=d.getDocument().get("NAME").toString();
                                        Log.d("ttt", "acctype:" + acctype);
                                        break;

                                    }

                                }
                            }
                            if (n == 1) {
                                editor.putString("ID",fid);
                                editor.putString("USERNAME", usr);
                                editor.putString("PASSWORD", psd);
                                editor.putString("ACCTYPE", acctype);
                                editor.putString("NAME",nm);
                                editor.apply();
                                Toast.makeText(login.this, "Signed in", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(getApplicationContext(), FisherMainHome.class));

                                finish();
                            } else {
                                Snackbar.make(vs, "Inavlid username or password", Snackbar.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });
    }

    public void redirectss(View view) {
        startActivity(new Intent(getApplicationContext(), CreateAcc.class));
    }
}
