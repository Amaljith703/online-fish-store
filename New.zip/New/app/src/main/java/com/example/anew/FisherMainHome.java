package com.example.anew;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.anew.ui.dashboard.DashboardFragment;
import com.example.anew.ui.home.HomeFragment;
import com.example.anew.ui.notifications.NotificationsFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import static com.example.anew.AddBidFragment.faber;
import static java.security.AccessController.getContext;

public class FisherMainHome extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    public static BottomNavigationView navView;
    private AppBarConfiguration mAppBarConfiguration;
    DrawerLayout drawer;
    String acctype;
   public static FloatingActionButton fab;
    TextView tname, ttype;
    NavigationView navigationView;
    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fisher_main_home);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        navView = findViewById(R.id.nav_viewer);

        sharedPreferences = this.getSharedPreferences("LOCAL", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        acctype = sharedPreferences.getString("ACCTYPE", null);
        String acname = sharedPreferences.getString("NAME", null);
        Log.d("ttt", "actyp:" + acctype);
        fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Fragment fragment = new AddBidFragment();
                FragmentManager fragmentManager = FisherMainHome.this.getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.nav_host_fragment, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
              //  Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                    //    .setAction("Action", null).show();
            }
        });
            fab.setVisibility(View.INVISIBLE);
     drawer = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow)
                .setDrawerLayout(drawer)
                .build();
        // LayoutInflater inflater = ((Activity) this).getLayoutInflater();
        // View v = inflater.inflate(R.layout.nav_header_fisher_main_home, navigationView, false);
        //    tname=v.findViewById(R.id.person_name);
        //    ttype=v.findViewById(R.id.acc_type);
        View headerView = navigationView.getHeaderView(0);
        tname = (TextView) headerView.findViewById(R.id.person_name);
        ttype = (TextView) headerView.findViewById(R.id.acc_type);
        // tname= (TextView) v.findViewById(R.id.person_name);

/*
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        NavController navControllers1 = Navigation.findNavController(FisherMainHome.this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(FisherMainHome.this, navControllers1, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navControllers1);

*/
////////////////navigation dashboard==stock /////notification===bid /////

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
        /////////////////////////////////////////////LOGOUT

        navigationView.getMenu().findItem(R.id.nav_signout).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                FisherMainHome.this.logout();

                return true;
            }
        });


        /////////////////////////////////////////////////////////////////


        tname.setText(acname);
        ttype.setText(acctype);

        ///////navigation drawer home button

        navView.getMenu().findItem(R.id.navigation_home).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                fab.setVisibility(View.INVISIBLE);
                Fragment fragment = new HomeFragment();
                FragmentManager fragmentManager = FisherMainHome.this.getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.nav_host_fragment, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
                return false;
            }
        });
        navView.getMenu().findItem(R.id.navigation_dashboard).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                fab.setVisibility(View.INVISIBLE);
                if (acctype.equals("FISHER")) {
                    Fragment fragment = new DashboardFragment();
                    FragmentManager fragmentManager = FisherMainHome.this.getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.nav_host_fragment, fragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                }
                else {
                    Fragment fragment = new DistDashStockFragment();
                    FragmentManager fragmentManager = FisherMainHome.this.getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.nav_host_fragment, fragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                }
                return false;
            }
        });

        navView.getMenu().findItem(R.id.navigation_notifications).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                fab.setVisibility(View.VISIBLE);
                if (acctype.equals("FISHER")) {
                    Fragment fragment = new NotificationsFragment();
                    FragmentManager fragmentManager = FisherMainHome.this.getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.nav_host_fragment, fragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                } else {
                    fab.setVisibility(View.INVISIBLE);
                    Fragment fragment = new DistNotifBidFragment();
                    FragmentManager fragmentManager = FisherMainHome.this.getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.nav_host_fragment, fragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                }
                return false;
            }
        });
    }
    private void homeButtonChange() {
        getSupportActionBar().setTitle("Home");
        if (acctype.equals("FISHER")) {
            Fragment fragment = new HomeFragment();
            FragmentManager fragmentManager = FisherMainHome.this.getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.nav_host_fragment, fragment);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
            drawer.closeDrawer(GravityCompat.START);
        } else {
            navView.setVisibility(View.VISIBLE);
            Fragment fragment = new DistributorHomeFragment();
            FragmentManager fragmentManager = FisherMainHome.this.getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.nav_host_fragment, fragment);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
            drawer.closeDrawer(GravityCompat.START);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.fisher_main_home, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    public void logout() {

        try {
            //fragment cannot directly use sharedpreference so use this.getActivity()     (this--fragment)
            editor.clear();
            editor.apply();
            startActivity(new Intent(this, login.class));
            finish();
        } catch (Exception v) {
            Toast.makeText(this, "error :" + v, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onBackPressed() {

       if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
            Log.d("ttt", "somthing working");
        } else {


         //  navView.getMenu().findItem(R.id.navigation_home).setChecked(true);
            super.onBackPressed();
        }

    
    }


}
