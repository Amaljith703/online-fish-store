package com.example.anew.ui.slideshow;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.anew.BidAddContent;
import com.example.anew.R;
import com.example.anew.UserBidDatas;
import com.example.anew.UsrBidData;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;
import static com.example.anew.FisherMainHome.fab;
import static com.example.anew.FisherMainHome.navView;

public class SlideshowFragment extends Fragment {
FirebaseDatabase rdb;
ArrayList<UsrBidData> bidDataList;
ArrayList<BidAddContent> bidAddContentList;
String uid;
HistoryAdapter historyAdapter;
RecyclerView recyclerView;
SwipeRefreshLayout refreshLayout;
    private SlideshowViewModel slideshowViewModel;
SharedPreferences sharedPreferences;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        navView.setVisibility(View.INVISIBLE);
        fab.setVisibility(View.INVISIBLE);
        View root = inflater.inflate(R.layout.fragment_slideshow, container, false);
        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rdb=FirebaseDatabase.getInstance();
        bidDataList=new ArrayList<>();
        bidAddContentList=new ArrayList<>();
        sharedPreferences=getActivity().getSharedPreferences("LOCAL", MODE_PRIVATE);
        uid=sharedPreferences.getString("ID","illa");
        refreshLayout=view.findViewById(R.id.swipe_refresh);
        historyAdapter=new HistoryAdapter(bidAddContentList);
        recyclerView=view.findViewById(R.id.history_recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(historyAdapter);
        SwipeRefreshLayout.OnRefreshListener onRefreshListener=new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refreshLayout.setRefreshing(true);
                getAllDatas();
            }
        };
        refreshLayout.setOnRefreshListener(onRefreshListener);
        onRefreshListener.onRefresh();
    }



    private  void getAllDatas()
    {
        if(uid.equals("illa"))
        {
            Toast.makeText(getActivity(), "Unable to load history login again", Toast.LENGTH_SHORT).show();
            getActivity().onBackPressed();
        }
        else
        {
            rdb.getReference().child("history").child(uid).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    bidDataList.clear();
                 for(DataSnapshot snapshot:dataSnapshot.getChildren())
                 {
                     if(snapshot.exists())
                     {
                         UsrBidData usrBidData=snapshot.getValue(UsrBidData.class);
                         bidDataList.add(usrBidData);
                     }
                 }

                 getAllBids();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    refreshLayout.setRefreshing(false);
                }
            });
        }
    }
    private void getAllBids()
    {
        bidAddContentList.clear();
        for(UsrBidData usrBidData:bidDataList) {
            rdb.getReference().child("BID").child(usrBidData.getCudate()).child(usrBidData.getSfishrID()).child(usrBidData.getSpid()).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
    if(dataSnapshot.exists())
    {
        BidAddContent bidAddContent=dataSnapshot.getValue(BidAddContent.class);
        bidAddContentList.add(bidAddContent);
        historyAdapter.notifyDataSetChanged();
    }

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
        refreshLayout.setRefreshing(false);
    }
}
