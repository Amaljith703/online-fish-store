package com.example.anew;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class StockAdapter extends RecyclerView.Adapter<StockAdapter.RequestViewHolder> implements Filterable {
    private ArrayList<StockItem> exampleList;
    private ArrayList<StockItem> exampleListFull;
    private OnItemClickListener mListener;
Context context;
    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    public static class RequestViewHolder extends RecyclerView.ViewHolder {

        private TextView textView1name;
        private TextView textView2qty;
        private TextView textView3loca;



        public RequestViewHolder(View itemView, final OnItemClickListener listener) {
            super(itemView);

            textView1name = itemView.findViewById(R.id.mstext1);
            textView2qty = itemView.findViewById(R.id.mstext2);
            textView3loca = itemView.findViewById(R.id.mstext3);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }
public void insertAll(ArrayList<StockItem> exampleList)
{
    exampleListFull = new ArrayList<>(exampleList);
    Log.e("ttt", "alller" +   exampleListFull.size()+"/"+exampleList.size());
}

    public StockAdapter(ArrayList<StockItem> exampleList) {
        if (exampleList != null) {
            this.exampleList = exampleList;

        }
    }

    @NonNull
    @Override
    public RequestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context=parent.getContext();
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.stockitem,
                parent, false);
        RequestViewHolder exvh = new RequestViewHolder(v, mListener);
        return exvh;
    }

    @Override
    public void onBindViewHolder(@NonNull RequestViewHolder holder, int position) {

        StockItem currentItem = exampleList.get(position);
        holder.textView1name.setText(currentItem.getName());
        holder.textView2qty.setText(""+currentItem.getQty());
        holder.textView3loca.setText(currentItem.getLocation());

 }

    @Override
    public int getItemCount() {
        return exampleList.size();
    }

    @Override
    public Filter getFilter() {
        return exampleFilter;
    }

    private Filter exampleFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            Log.e("ttt", "ddd1"+constraint);
            ArrayList<StockItem> filteredList = new ArrayList<>();
            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll((List) exampleListFull);

                Log.e("ttt", "ddd2" +  exampleListFull.size());
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();
                for (StockItem item : exampleListFull) {
                    if (item.getName().toLowerCase().contains(filterPattern)  ) {
                        filteredList.add(item);
                        Log.e("ttt", "ddd3" + filteredList.size());
                    }
                }

            }
            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            try {
                exampleList.clear();
                exampleList.addAll((List) results.values);
                notifyDataSetChanged();
            }
            catch (Exception e)
            {

            }
        }
    };
}