package com.worker.admin;

import android.net.Uri;

public class BloodDonateItem {
    private String mText1;
    private String mText2;
    private String mText3;
    private String mText4;
    private String ids;
    private  String name;
    private String price;
    private String imgs;
    private Uri img;

    public Uri getImg() {
        return img;
    }

    public void setImg(Uri img) {
        this.img = img;
    }

    public String getImgs() {
        return imgs;
    }

    public void setImgs(String imgs) {
        this.imgs = imgs;
    }

    public BloodDonateItem()
    {

    }
public BloodDonateItem insertdata(String ider,String namer,String pricer,Uri im)
{
    BloodDonateItem s=new BloodDonateItem();
    s.setIds(ider);
    s.setName(namer);
    s.setPrice(pricer);
    s.setImg(im);
    return s;
}
    public String getIds() {
        return ids;
    }

    public void setIds(String ids) {
        this.ids = ids;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public BloodDonateItem(String text1, String text2, String text3, String text4)
    {
        mText1=text1;
        mText2=text2;
        mText3=text3;
        mText4=text4;
    }
    public String contactNumber()
    {
        return mText1;
    }

    public String getmText1()
    {
        return mText1;
    }
    public String getmText2()
    {
        return mText2;
    }
    public String getmText3()
    {
        return mText3;
    }
    public String getmText4(){return  mText4;}
}
