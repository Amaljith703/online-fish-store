npackage com.worker.admin;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;


/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class DeleteID extends FragmentActivity {
private static String contact=null;
View view;
FirebaseFirestore fs;
Button call,cancel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
LayoutInflater inflater;
ViewGroup root;
view=LayoutInflater.from(getApplicationContext()).inflate(R.layout.delete_id,null,false);
        setContentView(R.layout.delete_id);
        fs=FirebaseFirestore.getInstance();
        call=findViewById(R.id.yess);
        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callmaker();
            }
        });
        cancel=findViewById(R.id.nooo);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notsent();
            }
        });
        Log.d("ttt", contact);
    }

    public void callperson(String contact) {
        this.contact = contact;


    }

    private void callmaker() {
  fs.collection("register").whereEqualTo("ID",contact).addSnapshotListener(new EventListener<QuerySnapshot>() {
      @Override
      public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
          for(DocumentChange d:queryDocumentSnapshots.getDocumentChanges())
          {
              if(d.getType()==DocumentChange.Type.ADDED)
              {
                  if(d.getDocument().exists())
                  {
                      Log.d("ttt", String.valueOf(d.getNewIndex()));
                      d.getDocument().getReference().delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                          @Override
                          public void onSuccess(Void aVoid) {
                              Log.d("ttt","yesseda");

                          }
                      }).addOnFailureListener(new OnFailureListener() {
                          @Override
                          public void onFailure(@NonNull Exception e) {

                          }
                      });

                  }
              }
          }
      }
  });
        notsent();
        }
    public void notsent()
    {
        super.onBackPressed();
    }

    }



