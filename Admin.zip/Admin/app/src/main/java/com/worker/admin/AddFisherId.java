package com.worker.admin;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class AddFisherId extends FragmentActivity {
    private static String contact = null;
    View view;
    EditText edttxt;
    Button call, cancel;
    int numff = 0,cls=0;
    FirebaseFirestore mFire;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.add_fisher_id, null, false);
        setContentView(R.layout.add_fisher_id);
        edttxt = findViewById(R.id.addids);
        mFire = FirebaseFirestore.getInstance();
        edttxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int length = s.length();
                String name = s.toString();
                if (length < 6) {
                    edttxt.setError("6 digit register number");
                    numff = 1;
                } else {
                    checkerVal(name);
                }
            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        call = findViewById(R.id.yess);
        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callmaker();
            }
        });
        cancel = findViewById(R.id.nooo);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notsent();
            }
        });
    }
    private void checkerVal(String ff) {
        String name = ff;
        numff = 0;
        mFire.collection("register").whereEqualTo("ID", name).addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                for (DocumentChange d : queryDocumentSnapshots.getDocumentChanges()) {
                    if (d.getType() == DocumentChange.Type.ADDED) {
                        numff = 2;
                        if (d.getDocument().exists()) {
                            numff = 1;
                            edttxt.setError("register number exist");
                            break;
                        }

                    }
                }

            }
        });
        Log.d("ttt", "state:" + numff);

    }

    private void callmaker() {

        final String vbb = edttxt.getText().toString();

        if (numff == 1) {
            edttxt.setError("6 digit register number");
        } else {
            numff = 0;
            mFire.collection("register").whereEqualTo("ID", vbb).addSnapshotListener(new EventListener<QuerySnapshot>() {
                @Override
                public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                    for (DocumentChange d : queryDocumentSnapshots.getDocumentChanges()) {
                        if (d.getType() == DocumentChange.Type.ADDED) {
                            numff = 2;
                            if (d.getDocument().exists()) {
                                numff = 1;
                                edttxt.setError("register number exist");
                                break;
                            }

                        }
                    }
                    if (numff == 0) {
                        Map<String, Object> mp = new HashMap<>();
                        mp.put("ID", vbb);
                        mFire.collection("register").add(mp).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                notsent();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                notsent();
                            }
                        });

                    } else if (numff == 1) {
                        edttxt.setError("register number exist");
                        notsent();
                    }

                }
            });
        }

    }

    public void notsent() {
        if(cls==0) {
            cls=1;
            super.onBackPressed();
        }
    }
}


