package com.worker.admin;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;

import static android.app.Activity.RESULT_OK;
import static com.worker.admin.ui.dashboard.DashboardFragment.ft;


public class AddNewFishRateFragment extends Fragment {
    private View view;
    ImageButton pickpicbutton, takepicbutton;
    Button saveFish;
    ProgressBar progs;
    private static final int CAMERA_REQUEST = 101;
    public static final int IMAGE_PICK_CODE = 1000;
    private StorageTask mtask;
    StorageReference storageimg;
    private Uri mCapturedImageURI, upURI, downloadUrl = null;
    File imgfile, f;
   static int n = 0, cnt = 0;
    EditText Txtname, txtrate;
    FirebaseDatabase rdb;
    public static final int PERMISSION_PICK_CODE = 1001;
    String nam = null;
    String rate = null;
    ImageView img;
ArrayList<BloodDonateItem> arrayls;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_add_new_fish_rate, container, false);
        takepicbutton = view.findViewById(R.id.buttoner);
        pickpicbutton = view.findViewById(R.id.filebutton);
        saveFish = view.findViewById(R.id.savefish);
        img = view.findViewById(R.id.imageViewerer);
        progs=view.findViewById(R.id.progs);
        progs.setVisibility(View.INVISIBLE);
        ft.setVisibility(View.INVISIBLE);
        arrayls=new ArrayList<>();
        new AllContentHomeAdmin().stick=1;
        Txtname = view.findViewById(R.id.fishnm);
        storageimg= FirebaseStorage.getInstance().getReference("FISH");
        txtrate = view.findViewById(R.id.fishratekg);
        rdb = FirebaseDatabase.getInstance();

        getDataorThis();
        saveFish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
saveEveryData();
            }
        });
        takepicbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String fileName = "temp.jpg";
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.TITLE, fileName);
                URL url;
                mCapturedImageURI = getActivity().getContentResolver().insert(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                imgfile = new File(mCapturedImageURI.getPath());
                f = new File(imgfile, imgfile.getName());
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                //if(cameraIntent.resolveActivity(getPackageManager())!=null)
                intent.putExtra(MediaStore.EXTRA_OUTPUT, mCapturedImageURI);
                startActivityForResult(intent, CAMERA_REQUEST);


            }
        });
        Txtname.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String ch=Txtname.getText().toString();
                if(ch==" " || ch.equals(" "))
                {
                    Txtname.setText("");
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        pickpicbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (getActivity().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                        String[] permission = {Manifest.permission.READ_EXTERNAL_STORAGE};
                        requestPermissions(permission, PERMISSION_PICK_CODE);
                    } else {
                        pickImageFromGallary();
                    }
                } else {
                    pickImageFromGallary();
                }

            }
        });


        return view;
    }

    @Override
    public void onPause() {
        super.onPause();

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {
            //  Bitmap photo = (Bitmap) data.getExtras().get("data");
            //   img.setImageBitmap(photo);
            //  img.setImageURI(mCapturedImageURI);  //// used to insert image into image view using uri of the image
            InputStream imageStream = null;
            try {
                Glide.with(this).load(mCapturedImageURI).centerCrop().into(img);
                n = 1;
            } catch (Exception e) {
                e.printStackTrace();
            }


        } else if (resultCode == RESULT_OK && requestCode == IMAGE_PICK_CODE) {
            try {
                InputStream imageStream = null;
                //    img.setImageURI(data.getData());
                mCapturedImageURI = data.getData();
              Glide.with(this).load(mCapturedImageURI).centerCrop().into(img);
                n = 1;
            } catch (Exception e) {

            }

        }

    }

    private void pickImageFromGallary() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, IMAGE_PICK_CODE);
    }


    private String getExtension(Uri uri) {
        ContentResolver cr = getActivity().getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(cr.getType(uri));
    }

    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float) width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }

    private void saveEveryData() {
        cnt=0;
        progs.setVisibility(View.VISIBLE);
        saveFish.setEnabled(false);
        if (n == 0) {
            Snackbar.make(view,"Please select image",400).show();
            progs.setVisibility(View.INVISIBLE);
saveFish.setEnabled(true);
        } else {
            nam = null;
            rate = null;
            nam = Txtname.getText().toString().trim();
            rate = txtrate.getText().toString();

            if (nam.equals(null) || nam == null || nam == " ") {
                saveFish.setEnabled(true);
                progs.setVisibility(View.INVISIBLE);
                cnt = 1;
            }

            if (rate.equals(null) || rate == null) {
                cnt = 1;
                saveFish.setEnabled(true);
                progs.setVisibility(View.INVISIBLE);
            }
            int tim=arrayls.size();
            for(int i=0;i<tim;i++)
            {
                String nm=arrayls.get(i).getName();
             if(nam.toLowerCase().equals(nm.toLowerCase()) || nam.toLowerCase()==nm.toLowerCase()  || nam.toLowerCase()+" "==nm.toLowerCase()+" ")
             {
                 Log.d("ggg","checker :"+nam+"/"+nm);
                 cnt=2;

             }

            }
            if (cnt == 1) {
                Snackbar.make(view, "Please fill columns correctly", Snackbar.LENGTH_SHORT).show();
                Log.d("gggg","fill column correctly");
                saveFish.setEnabled(true);
            }
            else if(cnt==2)
            {

                Snackbar.make(view, "Sorry data already exist ", Snackbar.LENGTH_SHORT).show();
            }
             else
            {
                if(isNetworkAvailable())
                {
                final StorageReference rf = storageimg.child(System.currentTimeMillis() + "." + getExtension(mCapturedImageURI));
                mtask = rf.putFile(mCapturedImageURI).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        rf.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {
                                downloadUrl = uri;
                                if (downloadUrl != null) {
                                    String ids = rdb.getReference().child("fishrate").push().getKey();
                                    BloodDonateItem fish = new BloodDonateItem();
                                    fish.setIds(ids);
                                    fish.setName(nam);
                                    fish.setPrice(rate);
                                    fish.setImgs(downloadUrl.toString());
                                    rdb.getReference().child("fishrate").child(ids).setValue(fish).addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            Snackbar.make(view, "Saved", 400).show();
                                            progs.setVisibility(View.INVISIBLE);
                                        //    Toast.makeText(getContext(), "saved", Toast.LENGTH_SHORT).show();
                                            Log.d("gggg", "Saved");
                                            saveFish.setEnabled(true);
                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            saveFish.setEnabled(true);
                                            progs.setVisibility(View.INVISIBLE);
                                            Log.d("gggg", "inner failure " + e);
                                            Toast.makeText(getContext(), "inner failure", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                } else {
                                    Log.d("gggg", "inner else");
                                    saveFish.setEnabled(true);
                                    progs.setVisibility(View.INVISIBLE);
                                }


                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.d("gggg", "middle failyure " + e);
                                saveFish.setEnabled(true);
                                progs.setVisibility(View.INVISIBLE);
                            }
                        });
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d("gggg", "outer failure " + e);
                        saveFish.setEnabled(true);
                        progs.setVisibility(View.INVISIBLE);
                    }
                });
            }
                else
                {
                    saveFish.setEnabled(true);
                    progs.setVisibility(View.INVISIBLE);
                    Snackbar.make(view, "Please enable network", 400).show();
                }
            }

        }

    }
    public boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        assert connectivityManager != null;
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
    private void getDataorThis()
    {

        rdb.getReference().child("fishrate").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                arrayls.clear();
                if(dataSnapshot.exists()) {
                    for (DataSnapshot childsnapshot : dataSnapshot.getChildren()) {
                        if(childsnapshot.exists())
                        {
                            BloodDonateItem bs=new BloodDonateItem();
                            String ider=childsnapshot.child("ids").getValue(String.class);
                            Uri img= Uri.parse(childsnapshot.child("imgs").getValue(String.class));
                            String name=childsnapshot.child("name").getValue(String.class);
                            String price=childsnapshot.child("price").getValue(String.class);
                            Log.d("mmm","ider "+ider);
                            Log.d("mmm","name "+name);
                            Log.d("mmm","price "+price);
                            arrayls.add(new BloodDonateItem().insertdata(ider,name,price,img));

                        }

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.d("gggg","database :"+databaseError.getMessage());
            }
        });


    }
}
