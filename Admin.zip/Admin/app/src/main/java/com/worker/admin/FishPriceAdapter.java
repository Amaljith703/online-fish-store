package com.worker.admin;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class FishPriceAdapter extends RecyclerView.Adapter<FishPriceAdapter.FishPriceViewHolder> {
    private ArrayList<BloodDonateItem> mBloodDonateList;
    private OnItemClickListener mListener;
    Context context;

    public interface OnItemClickListener {
        void onItemClick(int position);

        void onCloseItem(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    public static class FishPriceViewHolder extends RecyclerView.ViewHolder {
        public TextView mTextView1;
        public TextView mTextView2;
        public ImageView imageView;
        public ImageButton closeBtn;

        public FishPriceViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);
            mTextView1 = itemView.findViewById(R.id.fTextView1);
            mTextView2 = itemView.findViewById(R.id.fTextView2);
            imageView = itemView.findViewById(R.id.fishimgview);
            closeBtn = itemView.findViewById(R.id.close_btn);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(position);
                        }
                    }
                }
            });

            closeBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onCloseItem(position);
                        }
                    }
                }
            });
        }
    }

    public FishPriceAdapter(ArrayList<BloodDonateItem> bloodlist) {
        mBloodDonateList = bloodlist;
    }

    @NonNull
    @Override
    public FishPriceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.fish_content, parent, false);
        FishPriceViewHolder bdvh = new FishPriceViewHolder(v, mListener);
        return bdvh;
    }

    @Override
    public void onBindViewHolder(@NonNull FishPriceViewHolder holder, int position) {
        BloodDonateItem currentitem = mBloodDonateList.get(position);
        //   Picasso.with(context).load(currentitem.getImg()).into(holder.imageView);
        Glide.with(context).load(currentitem.getImg())
                .centerCrop()
                .into(holder.imageView);
        holder.mTextView1.setText(currentitem.getName());
        holder.mTextView2.setText(currentitem.getPrice());

    }

    @Override
    public int getItemCount() {
        return mBloodDonateList.size();
    }

}
