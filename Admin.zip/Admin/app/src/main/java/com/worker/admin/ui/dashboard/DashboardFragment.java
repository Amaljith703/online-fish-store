package com.worker.admin.ui.dashboard;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.TranslateAnimation;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.worker.admin.AddNewFishRateFragment;
import com.worker.admin.BloodDonateAdapter;
import com.worker.admin.BloodDonateItem;
import com.worker.admin.FishPriceAdapter;
import com.worker.admin.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DashboardFragment extends Fragment {
public static FloatingActionButton ft;
    private DashboardViewModel dashboardViewModel;
    RecyclerView rs;
    FishPriceAdapter mAdapter;
    FirebaseDatabase rdb;    EditText name;
    EditText qty;
    Button cancel, add;
    CardView cardView;
    boolean opened;
    String dt=null,dname=null,drate=null;
    private ArrayList<BloodDonateItem> arrayls;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_dashboard, container, false);
       ft=root.findViewById(R.id.floatingActionBut);
       rdb=FirebaseDatabase.getInstance();
        arrayls= new ArrayList<>();
        rs=root.findViewById(R.id.fishrecycler);
        ft.setVisibility(View.VISIBLE);
        name = root.findViewById(R.id.autocompletetext);
        qty = root.findViewById(R.id.stockqty);
        add = root.findViewById(R.id.stockadd);
        cancel = root.findViewById(R.id.stockcancel);
        cardView=root.findViewById(R.id.cardstock);
        close();
        name.setVisibility(View.INVISIBLE);
        qty.setVisibility(View.INVISIBLE);
        add.setVisibility(View.INVISIBLE);
        cancel.setVisibility(View.INVISIBLE);

        opened = false;
        cardView.setVisibility(View.INVISIBLE);
       ft.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
           AddNewFishRateFragment addres=new AddNewFishRateFragment();
               FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
               FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
               fragmentTransaction.replace(R.id.dashborder, addres);
               fragmentTransaction.addToBackStack(null);
               fragmentTransaction.commit();
           }
       });
        rs.setLayoutManager(new LinearLayoutManager(getContext()));
        mAdapter=new FishPriceAdapter(arrayls);
        rs.setAdapter(mAdapter);
getDataorThis();
cancel.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        close();
    }
});
add.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
updateFishPrice();
    }
});
mAdapter.setOnItemClickListener(new FishPriceAdapter.OnItemClickListener() {
    @Override
    public void onItemClick(int position) {
 dt=arrayls.get(position).getIds();
dname=arrayls.get(position).getName();
drate=arrayls.get(position).getPrice();
name.setText(dname);
qty.setText(drate);
        if (!opened) {
            name.setVisibility(View.VISIBLE);
            cardView.setVisibility(View.VISIBLE);
            qty.setVisibility(View.VISIBLE);
            add.setVisibility(View.VISIBLE);
            cancel.setVisibility(View.VISIBLE);
            TranslateAnimation animate = new TranslateAnimation(
                    0,
                    0,
                    cardView.getHeight(),
                    0);
            animate.setDuration(500);
            animate.setFillAfter(true);
            cardView.startAnimation(animate);
            Handler b = new Handler();
            b.postDelayed(new Runnable() {
                @Override
                public void run() {


                }
            }, 200);
            opened = !opened;
            ft.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void onCloseItem(final int position) {

        AlertDialog.Builder builder=new AlertDialog.Builder(getActivity());
        builder.setTitle("Delete")
                .setMessage("Do you want to delete..?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        String id=arrayls.get(position).getIds();
                        rdb.getReference().child("fishrate").child(id).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                Toast.makeText(getActivity(), "Scessfully deleted", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
});
        return root;
    }
    public void close() {
        if (opened) {
            dname=null;
            drate=null;
            dt=null;
            name.setText("");
            qty.setText("");
            cardView.setVisibility(View.VISIBLE);
            name.setVisibility(View.INVISIBLE);
            qty.setVisibility(View.INVISIBLE);
            add.setVisibility(View.INVISIBLE);
            cancel.setVisibility(View.INVISIBLE);
            TranslateAnimation animate = new TranslateAnimation(
                    0,
                    0,
                    0,
                    cardView.getHeight());
            animate.setDuration(300);
            animate.setFillAfter(true);
            cardView.startAnimation(animate);
            Handler b = new Handler();
            b.postDelayed(new Runnable() {
                @Override
                public void run() {
                    cardView.setVisibility(View.INVISIBLE);
                    ft.setVisibility(View.VISIBLE);
                }
            }, 300);
            opened = !opened;
        }
    }
    private void getDataorThis()
        {
            rdb.getReference().child("fishrate").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    arrayls.clear();
                    if(dataSnapshot.exists()) {
                        for (DataSnapshot childsnapshot : dataSnapshot.getChildren()) {
                              if(childsnapshot.exists())
                              {
                                  BloodDonateItem bs=new BloodDonateItem();
                                  String ider=childsnapshot.child("ids").getValue(String.class);
                                  Uri img= Uri.parse(childsnapshot.child("imgs").getValue(String.class));
                                  String name=childsnapshot.child("name").getValue(String.class);
                                  String price=childsnapshot.child("price").getValue(String.class);
                                  Log.d("mmm","ider "+ider);
                                  Log.d("mmm","name "+name);
                                  Log.d("mmm","price "+price);
                                  arrayls.add(new BloodDonateItem().insertdata(ider,name,price,img));
                              }
                        }
                        mAdapter.notifyDataSetChanged();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Log.d("gggg","database :"+databaseError.getMessage());
                }
            });


    }
    private void updateFishPrice()
    {
        String namr=name.getText().toString().trim();
        String price=qty.getText().toString().trim();
        int nk=0;
        if(namr.length()==0)
        {
            nk=1;
            name.setError("Fill column");
        }
        if(price.length()==0)
        {
            nk=1;
            qty.setError("Fill column");
        }
        if(nk==0) {
            Map<String, Object> map = new HashMap<>();
            map.put("price",price );
            map.put("name",namr);
            rdb.getReference().child("fishrate").child(dt).updateChildren(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful())
                    {
                        Toast.makeText(getContext(), "Updated sucessfully", Toast.LENGTH_SHORT).show();
                    }
                    else {

                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {

                }
            });
        }
    }
}
