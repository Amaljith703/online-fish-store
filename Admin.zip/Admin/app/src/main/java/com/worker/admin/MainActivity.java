package com.worker.admin;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.ArrayList;
public class MainActivity extends AppCompatActivity {
    FirebaseFirestore d;
    RecyclerView rs;
    BloodDonateAdapter mAdapter;
    FloatingActionButton ftbt;
    private ArrayList<BloodDonateItem> arrayls;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       d=FirebaseFirestore.getInstance();
       arrayls= new ArrayList<>();
       rs=findViewById(R.id.recycler);
       ftbt=findViewById(R.id.floatingActionButton);
       ftbt.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
            startActivity(new Intent(getApplicationContext(),AddFisherId.class));
           }
       });
        rs.setLayoutManager(new LinearLayoutManager(this));
        mAdapter=new BloodDonateAdapter(arrayls);
        rs.setAdapter(mAdapter);
       mAdapter.setOnItemClickListener(new BloodDonateAdapter.OnItemClickListener() {
           @Override
           public void onItemClick(int position) {
               String id=arrayls.get(position).contactNumber();
               new DeleteID().callperson(id);
               startActivity(new Intent(getApplicationContext(),DeleteID.class));
           }
       });

       d.collection("register").addSnapshotListener(new EventListener<QuerySnapshot>() {
           @Override
           public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                 Log.d("ttt","adding");
               for(DocumentChange rs:queryDocumentSnapshots.getDocumentChanges())
               {Log.d("ttt", "11");
                   if(rs.getType()==DocumentChange.Type.ADDED)
                   {
                   String namees="",phnos="",locs="";
                       if(rs.getDocument().exists()) {
                           String s = null;
                           Log.d("ttt", "22");
                           if (rs.getDocument().get("ID")!= null) {
                               s = rs.getDocument().get("ID").toString();
                               Log.d("ttt", s);
                               if(rs.getDocument().get("NAME")!=null)
                               {
                                   namees=rs.getDocument().get("NAME").toString();
                               }
                               if(rs.getDocument().get("CONTACT")!=null)
                               {
                                   phnos=rs.getDocument().get("CONTACT").toString();
                               }
                               if(rs.getDocument().get("LOCATION")!=null)
                               {
                                   locs=rs.getDocument().get("LOCATION").toString();
                               }
                               arrayls.add(new BloodDonateItem(s,namees,phnos,locs));
                               mAdapter.notifyDataSetChanged();
                           }

                       }
                   }
                   if(rs.getType()==DocumentChange.Type.REMOVED)
                   {
                       d.collection("register").addSnapshotListener(new EventListener<QuerySnapshot>() {
                           @Override
                           public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                               Log.d("ttt","deleting");
                               arrayls.clear();
                               for(DocumentChange ns:queryDocumentSnapshots.getDocumentChanges()) {
                                   Log.d("ttt", "11");
                                   if (ns.getType() == DocumentChange.Type.ADDED) {
                                       String namees = "", phnos = "", locs = "";
                                       if (ns.getDocument().exists()) {
                                           String s = null;
                                           Log.d("ttt", "22");
                                           if (ns.getDocument().get("ID") != null) {
                                               s = ns.getDocument().get("ID").toString();
                                               Log.d("ttt", s);
                                               if (ns.getDocument().get("NAME") != null) {
                                                   namees = ns.getDocument().get("NAME").toString();
                                               }
                                               if (ns.getDocument().get("CONTACT") != null) {
                                                   phnos = ns.getDocument().get("CONTACT").toString();
                                               }
                                               if (ns.getDocument().get("LOCATION") != null) {
                                                   locs = ns.getDocument().get("LOCATION").toString();
                                               }
                                               arrayls.add(new BloodDonateItem(s, namees, phnos, locs));
                                               mAdapter.notifyDataSetChanged();
                                           }

                                       }
                                   }
                               }
                           }
                       });
                   }

               }

           }
       });

    }
}
